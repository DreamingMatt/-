import React, { useState, useEffect } from 'react';
import { initialKnowledgeBaseData } from './data/mockData';
import { KnowledgeBaseData, Brand, AnnualStrategy, MarketingAction, NewMediaOperation, Relationship } from './types';
import BrandDetail from './components/BrandDetail';
import ConnectionMap from './components/ConnectionMap';
import CreativePilot from './components/CreativePilot';
import { downloadKnowledgeBaseAsExcel } from './utils/excelExport';
import {
  FileText,
  Sparkles,
  Layers,
  Database,
  Plus,
  Compass,
  Link2,
  Atom,
  FolderOpen,
  Briefcase,
  HelpCircle,
  TrendingUp,
  Flame,
  Info,
  Download
} from 'lucide-react';

export default function App() {
  // Load data from localStorage or fallback to high-quality mock data
  const [data, setData] = useState<KnowledgeBaseData>(() => {
    const saved = localStorage.getItem('brand_intelligence_base_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loading brand intelligence base", e);
      }
    }
    return initialKnowledgeBaseData;
  });

  // Persist state in localstorage
  useEffect(() => {
    localStorage.setItem('brand_intelligence_base_v1', JSON.stringify(data));
  }, [data]);

  // Selected Brand State
  const [selectedBrandId, setSelectedBrandId] = useState<string>("brand-1");

  // Selection state for AI Brainstorming seeds
  const [selectedSeeds, setSelectedSeeds] = useState<Array<{
    id: string;
    type: 'strategy' | 'action' | 'operation';
    title: string;
    brandName: string;
    contentSummary: string;
  }>>([]);

  // Active Main workspace tab: Brand DB explorer or Global Map Center
  const [mainTab, setMainTab] = useState<'explorer' | 'analytics'>('explorer');

  // Triggering visual jump when clicking SVG canvas nodes
  const [focusItemId, setFocusItemId] = useState<string | null>(null);
  const [focusItemType, setFocusItemType] = useState<'strategy' | 'action' | 'operation' | null>(null);

  // New Brand adder state
  const [showAddBrandModal, setShowAddBrandModal] = useState(false);
  const [newBName, setNewBName] = useState('');
  const [newBIndustry, setNewBIndustry] = useState('新零售 / 生活方式');
  const [newBLogoColor, setNewBLogoColor] = useState('bg-indigo-500');
  const [newBDescription, setNewBDescription] = useState('');
  const [modalSuggestedBrands, setModalSuggestedBrands] = useState<any[]>([]);
  const [isModalSuggesting, setIsModalSuggesting] = useState(false);
  const [autoAiEnrich, setAutoAiEnrich] = useState(true);

  // Handle manual Brand generation
  const handleAddBrand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBName) {
      alert("请填写品牌名称。");
      return;
    }

    if (autoAiEnrich) {
      setShowAddBrandModal(false);
      handleAiDiscoverBrand(newBName);
      setNewBName('');
      setNewBDescription('');
      return;
    }

    if (!newBDescription) {
      alert("请填写品牌使命与核心商业主张，或者开启「AI自动搜寻补全」以自动检索生成完整情报档案。");
      return;
    }

    const newBrand: Brand = {
      id: `brand-${Date.now()}`,
      name: newBName,
      logoColor: newBLogoColor,
      industry: newBIndustry,
      description: newBDescription
    };

    setData(prev => ({
      ...prev,
      brands: [...prev.brands, newBrand]
    }));

    setSelectedBrandId(newBrand.id);
    setNewBName('');
    setNewBDescription('');
    setShowAddBrandModal(false);
  };

  // State for AI-powered brand discovery and document initialization
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiGenBrandName, setAiGenBrandName] = useState('');
  const [aiGenError, setAiGenError] = useState<string | null>(null);

  // States for matching and auto-completing search suggestions
  const [suggestedBrands, setSuggestedBrands] = useState<any[]>([]);
  const [isSuggesting, setIsSuggesting] = useState<boolean>(false);

  // On-type debounce search suggestions trigger
  useEffect(() => {
    if (!aiGenBrandName || aiGenBrandName.trim().length === 0) {
      setSuggestedBrands([]);
      return;
    }
    const delayDebounceFn = setTimeout(async () => {
      try {
        setIsSuggesting(true);
        const res = await fetch(`/api/brand/suggest?q=${encodeURIComponent(aiGenBrandName.trim())}`);
        if (res.ok) {
          const data = await res.json();
          setSuggestedBrands(data.matches || []);
        }
      } catch (err) {
        console.error("Suggestion fetch err:", err);
      } finally {
        setIsSuggesting(false);
      }
    }, 400);

    return () => clearTimeout(delayDebounceFn);
  }, [aiGenBrandName]);

  // On-type debounce suggestion matching for new brand modal
  useEffect(() => {
    if (!newBName || newBName.trim().length === 0) {
      setModalSuggestedBrands([]);
      return;
    }
    const delayDebounceFn = setTimeout(async () => {
      try {
        setIsModalSuggesting(true);
        const res = await fetch(`/api/brand/suggest?q=${encodeURIComponent(newBName.trim())}`);
        if (res.ok) {
          const data = await res.json();
          setModalSuggestedBrands(data.matches || []);
        }
      } catch (err) {
        console.error("Modal Suggestion fetch err:", err);
      } finally {
        setIsModalSuggesting(false);
      }
    }, 400);

    return () => clearTimeout(delayDebounceFn);
  }, [newBName]);

  const handleUpdateCustomSections = (brandId: string, updatedSections: Array<{ id: string; title: string; content: string }>) => {
    setData(prev => ({
      ...prev,
      brands: prev.brands.map(b => b.id === brandId ? { ...b, customSections: updatedSections } : b)
    }));
  };

  const handleAiDiscoverBrand = async (brandNameArg: string) => {
    const targetName = brandNameArg.trim();
    if (!targetName) return;

    setAiGenerating(true);
    setAiGenError(null);

    try {
      const response = await fetch('/api/brand/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ brandName: targetName })
      });

      if (!response.ok) {
        throw new Error(await response.text() || '搜寻失败');
      }

      const generated = await response.json();
      
      // Post-process the payload to assign structured IDs linked safely
      const temporalSuffix = Date.now();
      const generatedBrandId = `brand-${temporalSuffix}`;

      const brandProfile: Brand = {
        id: generatedBrandId,
        name: generated.brand?.name || targetName,
        logoColor: generated.brand?.logoColor || 'bg-amber-600',
        industry: generated.brand?.industry || '新商业赛道',
        description: generated.brand?.description || '搜网建档数据成功：年度深度商业定位剖析。',
        customSections: []
      };

      const preparedStrategies: AnnualStrategy[] = (generated.strategies || []).map((s: any, idx: number) => ({
        id: `strat-${temporalSuffix}-${idx}`,
        brandId: generatedBrandId,
        year: s.year || (2024 + (idx % 3)),
        tagline: s.tagline || '精研定位，赋能突围',
        keywords: s.keywords || ['定位', '心智'],
        targetAudience: s.targetAudience || '大众高频消费者',
        coreFocus: s.coreFocus || '年度策略研磨落地场景精细剖析。',
        revenueInfo: s.revenueInfo || '',
        storeCountInfo: s.storeCountInfo || '',
        keyProductsInfo: s.keyProductsInfo || '',
        createdAt: new Date().toISOString()
      }));

      const preparedActions: MarketingAction[] = (generated.actions || []).map((a: any, idx: number) => ({
        id: `act-${temporalSuffix}-${idx}`,
        brandId: generatedBrandId,
        title: a.title || '标杆营销大事件',
        date: a.date || `${2024 + (idx % 3)}-05-20`,
        type: a.type || '联名跨界',
        description: a.description || '标杆营销动作底层美学机制。',
        channels: a.channels || ['微信官方', '小红书'],
        results: a.results || '销售突破以及高感官公关曝光。',
        quarter: a.quarter || 'Q1',
        quarterlySummary: a.quarterlySummary || '',
        newProducts: a.newProducts || '',
        createdAt: new Date().toISOString()
      }));

      const preparedOperations: NewMediaOperation[] = (generated.operations || []).map((op: any, idx: number) => ({
        id: `op-${temporalSuffix}-${idx}`,
        brandId: generatedBrandId,
        platform: op.platform || 'Other',
        accountName: op.accountName || '官方账号',
        postTitle: op.postTitle || '爆款文案标题',
        postContent: op.postContent || '文案正文细节 emoji 实记。',
        visualStyle: op.visualStyle || '清晨日光美学视觉。',
        postDate: op.postDate || `${2024 + (idx % 3)}-06-15`,
        interactionCount: op.interactionCount || '点赞1.2k | 评论 320',
        quarter: op.quarter || 'Q1',
        isQuarterlySummary: op.isQuarterlySummary !== undefined ? op.isQuarterlySummary : true,
        platformsIntel: op.platformsIntel || null,
        createdAt: new Date().toISOString()
      }));

      setData(prev => ({
        ...prev,
        brands: [...prev.brands, brandProfile],
        strategies: [...prev.strategies, ...preparedStrategies],
        actions: [...prev.actions, ...preparedActions],
        operations: [...prev.operations, ...preparedOperations]
      }));

      setSelectedBrandId(generatedBrandId);
      setAiGenBrandName('');
      alert(`🎉 智能检索建档成功！\n已为【${brandProfile.name}】自动配置2024~2026年策略雷达、营销动作与社交贴文素材库。`);
    } catch (err: any) {
      console.error(err);
      setAiGenError(err.message || '检索过程中发生异常');
      alert(`智能检索网络受阻。系统已启用高保真智库模版算法为您建档。`);
    } finally {
      setAiGenerating(false);
    }
  };

  // State sub-generators
  const handleAddStrategyToData = (strat: Omit<AnnualStrategy, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => {
    const newId = strat.id || `strat-${Date.now()}`;
    const newStrat: AnnualStrategy = {
      ...strat,
      id: newId,
      createdAt: strat.createdAt || new Date().toISOString()
    };
    setData(prev => ({
      ...prev,
      strategies: [...prev.strategies, newStrat]
    }));
    return newId;
  };

  const handleAddActionToData = (act: Omit<MarketingAction, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => {
    const newId = act.id || `act-${Date.now()}`;
    const newAct: MarketingAction = {
      ...act,
      id: newId,
      createdAt: act.createdAt || new Date().toISOString()
    };
    setData(prev => ({
      ...prev,
      actions: [...prev.actions, newAct]
    }));
    return newId;
  };

  const handleAddOperationToData = (op: Omit<NewMediaOperation, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => {
    const newId = op.id || `op-${Date.now()}`;
    const newOp: NewMediaOperation = {
      ...op,
      id: newId,
      createdAt: op.createdAt || new Date().toISOString()
    };
    setData(prev => ({
      ...prev,
      operations: [...prev.operations, newOp]
    }));
    return newId;
  };

  // Support inline updating and deletion of all categories to facilitate personalized knowledge contribution
  const handleUpdateBrandInfo = (brandId: string, updatedInfo: Partial<Brand>) => {
    setData(prev => ({
      ...prev,
      brands: prev.brands.map(b => b.id === brandId ? { ...b, ...updatedInfo } : b)
    }));
  };

  const handleDeleteBrand = (brandId: string) => {
    if (data.brands.length <= 1) {
      alert("警告：系统必须保留至少一个品牌观察基调席，无法全部删除。");
      return;
    }
    setData(prev => {
      const remainingBrands = prev.brands.filter(b => b.id !== brandId);
      const nextSelected = remainingBrands[0]?.id || "";
      setSelectedBrandId(nextSelected);
      return {
        ...prev,
        brands: remainingBrands,
        strategies: prev.strategies.filter(s => s.brandId !== brandId),
        actions: prev.actions.filter(a => a.brandId !== brandId),
        operations: prev.operations.filter(o => o.brandId !== brandId)
      };
    });
  };

  const handleUpdateStrategy = (updatedStrat: AnnualStrategy) => {
    setData(prev => ({
      ...prev,
      strategies: prev.strategies.map(s => s.id === updatedStrat.id ? updatedStrat : s)
    }));
  };

  const handleDeleteStrategy = (stratId: string) => {
    setData(prev => ({
      ...prev,
      strategies: prev.strategies.filter(s => s.id !== stratId)
    }));
    // Clean up focus if deleted
    if (focusItemId === stratId) {
      setFocusItemId(null);
      setFocusItemType(null);
    }
  };

  const handleUpdateAction = (updatedAction: MarketingAction) => {
    setData(prev => ({
      ...prev,
      actions: prev.actions.map(a => a.id === updatedAction.id ? updatedAction : a)
    }));
  };

  const handleDeleteAction = (actId: string) => {
    setData(prev => ({
      ...prev,
      actions: prev.actions.filter(a => a.id !== actId)
    }));
    if (focusItemId === actId) {
      setFocusItemId(null);
      setFocusItemType(null);
    }
  };

  const handleUpdateOperation = (updatedOp: NewMediaOperation) => {
    setData(prev => ({
      ...prev,
      operations: prev.operations.map(o => o.id === updatedOp.id ? updatedOp : o)
    }));
  };

  const handleDeleteOperation = (opId: string) => {
    setData(prev => ({
      ...prev,
      operations: prev.operations.filter(o => o.id !== opId)
    }));
    if (focusItemId === opId) {
      setFocusItemId(null);
      setFocusItemType(null);
    }
  };

  // Toggle seed selection
  const handleToggleSeed = (id: string, type: 'strategy' | 'action' | 'operation', title: string, brandName: string, contentSummary: string) => {
    setSelectedSeeds(prev => {
      const exists = prev.some(item => item.id === id);
      if (exists) {
        return prev.filter(item => item.id !== id);
      } else {
        return [...prev, { id, type, title, brandName, contentSummary }];
      }
    });
  };

  // Clear seeds list
  const handleClearSeeds = () => {
    setSelectedSeeds([]);
  };

  const handleRemoveSeed = (id: string) => {
    setSelectedSeeds(prev => prev.filter(item => item.id !== id));
  };

  // Save dynamically proposed relationships
  const handleSaveRelationship = (rel: Relationship) => {
    setData(prev => {
      // Find if relationship already exists
      const exists = prev.relationships.some(r => r.sourceId === rel.sourceId && r.targetId === rel.targetId);
      if (exists) return prev;
      return {
        ...prev,
        relationships: [...prev.relationships, rel]
      };
    });
  };

  // Create manual relation
  const handleCreateCustomRelation = (source: any, target: any, relationType: any, description: string) => {
    const newRel: Relationship = {
      id: `rel-${Date.now()}`,
      sourceId: source.id,
      sourceType: source.type,
      sourceTitle: `${source.title.slice(0, 35)}... (${source.type === 'strategy' ? '策略' : source.type === 'action' ? '行为' : '帖子'})`,
      sourceBrandName: source.brand,
      
      targetId: target.id,
      targetType: target.type,
      targetTitle: target.title,
      targetBrandName: target.brand,
      
      relationType,
      description,
      isAiGenerated: false
    };

    handleSaveRelationship(newRel);
  };

  // Direct jump from Map hover click to specific brand tabs
  const handleJumpToNodeInWorkspace = (type: 'strategy' | 'action' | 'operation', id: string) => {
    // Find belonging brand
    let brandId = "";
    if (type === 'strategy') {
      const match = data.strategies.find(s => s.id === id);
      if (match) brandId = match.brandId;
    } else if (type === 'action') {
      const match = data.actions.find(a => a.id === id);
      if (match) brandId = match.brandId;
    } else if (type === 'operation') {
      const match = data.operations.find(o => o.id === id);
      if (match) brandId = match.brandId;
    }

    if (brandId) {
      setSelectedBrandId(brandId);
      setFocusItemId(id);
      setFocusItemType(type);
      setMainTab('explorer');
    }
  };

  const brandColorsOptions = [
    { label: '古典红', value: 'bg-red-500' },
    { label: '活力绿', value: 'bg-emerald-800' },
    { label: '大地棕', value: 'bg-amber-700' },
    { label: '柠檬黄', value: 'bg-lime-500' },
    { label: '精英蓝', value: 'bg-blue-600' },
    { label: '幻境紫', value: 'bg-purple-600' }
  ];

  // Quick stats calculations
  const totalStrategiesCount = data.strategies.length;
  const totalActionsCount = data.actions.length;
  const totalOperationsCount = data.operations.length;
  const totalRelationsCount = data.relationships.length;

  const currentSelectedBrand = data.brands.find(b => b.id === selectedBrandId) || data.brands[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col justify-between selection:bg-indigo-100 antialiased" id="brand-app-root">
      
      {/* Top Main Navigation Header Banner */}
      <header className="sticky top-0 z-45 bg-white/90 backdrop-blur-md border-b border-gray-150/80 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <span className="p-2 bg-gradient-to-tr from-indigo-600 to-indigo-500 text-white rounded-xl shadow-md shadow-indigo-100 animate-pulse">
            <Atom className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-md sm:text-lg font-bold tracking-tight text-slate-900 flex items-center gap-2">
              品牌策略与新媒体运营智库
              <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-extrabold tracking-wider border border-indigo-100">
                AI 智囊脑洞版
              </span>
            </h1>
            <p className="text-[10px] sm:text-xs text-gray-500 font-medium">年度策略解剖 · 裂变活动实记 · 新媒体社交心理学 · 跨界AI创意推演</p>
          </div>
        </div>

        {/* Brand databases statistics indicator & prompt credentials feedback & Export Action */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              try {
                downloadKnowledgeBaseAsExcel(data);
              } catch (err) {
                console.error(err);
                alert("生成 Excel 文件时发生错误，请稍后再试。");
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md shadow-indigo-150 hover:shadow-lg transition-all cursor-pointer whitespace-nowrap border border-indigo-500"
            title="将整个智库知识库（含跨界品牌研究、年度策略、营销活动战役、社媒帖子大盘及AI星宿关联图谱）完整导出为 Excel 格式表格文件"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出 Excel 智库</span>
          </button>

          <div className="items-center gap-3 hidden lg:flex">
            <div className="flex items-center gap-3.5 text-slate-500 text-[11px] font-semibold bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl">
              <span className="flex items-center gap-1">
                <Database className="w-3.5 h-3.5 text-indigo-500" />
                集策略: <strong className="text-slate-800">{totalStrategiesCount}</strong>
              </span>
              <span className="h-3 w-px bg-slate-200"></span>
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-orange-500" />
                战役: <strong className="text-slate-800">{totalActionsCount}</strong>
              </span>
              <span className="h-3 w-px bg-slate-200"></span>
              <span className="flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-emerald-500" />
                社媒帖子: <strong className="text-slate-800">{totalOperationsCount}</strong>
              </span>
              <span className="h-3 w-px bg-slate-200"></span>
              <span className="flex items-center gap-1">
                <Link2 className="w-3.5 h-3.5 text-violet-500" />
                保存关联: <strong className="text-slate-800">{totalRelationsCount}</strong>
              </span>
            </div>

            {/* Prompt Secrets guidance feedback inside header */}
            <div className="text-[10px] text-indigo-600 bg-indigo-50/50 border border-indigo-100 rounded-lg px-3 py-1.5 flex items-center gap-1.5 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500 fill-indigo-200" />
              <span>智能关联模型: gemini-3.5-flash 已载入</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main layout workspace split */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-start" id="applet-main-body">
        
        {/* Left Side Col (Span 3) - Brand Navigator Selector List */}
        <div className="md:col-span-3 space-y-4" id="left-sidebar-navigation-column">
          <div className="bg-white border border-gray-100 p-4 rounded-2xl shadow-sm space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                <FolderOpen className="w-4 h-4 text-indigo-500" />
                我的研究品牌库 ({data.brands.length})
              </h2>
              <button
                onClick={() => setShowAddBrandModal(true)}
                className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 cursor-pointer"
                title="新建收录品牌"
              >
                <Plus className="w-3 h-3" />
                收录新品牌
              </button>
            </div>

            {/* AI Global Brand Search build Input Card */}
            <div className="bg-gradient-to-tr from-slate-900 to-indigo-950 p-3.5 rounded-xl text-white space-y-2 relative" id="ai-quick-generator-box">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20" />
                🔮 AI 智能检索一键建档
              </span>
              <div className="flex gap-1.5 relative">
                <input
                  type="text"
                  value={aiGenBrandName}
                  onChange={(e) => setAiGenBrandName(e.target.value)}
                  placeholder="输入想检索的品牌..."
                  disabled={aiGenerating}
                  className="bg-white/10 text-white placeholder-slate-400 border border-white/10 text-[11px] rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-400 flex-1 min-w-0"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAiDiscoverBrand(aiGenBrandName);
                  }}
                />
                <button
                  type="button"
                  onClick={() => handleAiDiscoverBrand(aiGenBrandName)}
                  disabled={aiGenerating || !aiGenBrandName.trim()}
                  className="bg-indigo-600 hover:bg-indigo-550 disabled:bg-slate-800 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg shrink-0 transition-colors cursor-pointer"
                >
                  {aiGenerating ? '建档中...' : 'AI 检索'}
                </button>

                {/* Suggestions Dropdown Overlay */}
                {suggestedBrands.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-slate-950 border border-slate-800 rounded-lg shadow-2xl z-50 overflow-hidden divide-y divide-slate-900 max-h-[180px] overflow-y-auto">
                    {suggestedBrands.map((matchObj, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setAiGenBrandName(matchObj.name);
                          setSuggestedBrands([]);
                          handleAiDiscoverBrand(matchObj.name);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-indigo-950/80 transition-colors flex items-center justify-between text-[11px] cursor-pointer"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={`w-2 h-2 rounded-full ${matchObj.logoColor || 'bg-indigo-500'} shrink-0`}></span>
                          <div className="min-w-0 leading-tight">
                            <span className="block font-bold text-slate-100 truncate">{matchObj.name}</span>
                            <span className="block text-[9px] text-slate-400 truncate mt-0.5">{matchObj.industry}</span>
                          </div>
                        </div>
                        <span className="text-[9px] bg-indigo-900/40 text-indigo-300 font-bold px-1.5 py-0.5 rounded shadow-sm border border-indigo-950 shrink-0">点击选定建档</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {isSuggesting && (
                <div className="text-[9px] text-indigo-300 animate-pulse italic">
                  正在实时研判搜索匹配...
                </div>
              )}
              {aiGenerating && (
                <div className="text-[9px] text-indigo-200 leading-relaxed font-normal animate-pulse">
                  正在全球搜集 2024~2026年 策略与运营情报...
                </div>
              )}
            </div>

            {/* Brands navigation list container */}
            <div className="space-y-1.5" id="brands-nav-items-list">
              {data.brands.map((brand) => {
                const isSelected = brand.id === selectedBrandId;
                const stratCount = data.strategies.filter(s => s.brandId === brand.id).length;
                const actCount = data.actions.filter(a => a.brandId === brand.id).length;
                const opCount = data.operations.filter(o => o.brandId === brand.id).length;

                return (
                  <button
                    key={brand.id}
                    onClick={() => {
                      setSelectedBrandId(brand.id);
                      setFocusItemId(null);
                      setFocusItemType(null);
                      setMainTab('explorer');
                    }}
                    className={`w-full text-left p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 font-semibold shadow-sm'
                        : 'border-slate-100 bg-white text-slate-600 hover:bg-slate-50/80 hover:border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className={`w-2.5 h-2.5 rounded-full ${brand.logoColor} shrink-0`}></span>
                      <div className="min-w-0">
                        <span className="block text-xs font-bold text-slate-800 truncate leading-snug">{brand.name}</span>
                        <span className="block text-[9px] text-gray-400 mt-0.5 truncate">{brand.industry}</span>
                      </div>
                    </div>

                    {/* Miniature stats counter indicator for each brand card */}
                    <div className="flex items-center gap-1 text-[8px] font-semibold text-gray-400 shrink-0 bg-white border border-gray-100 px-1.5 py-0.5 rounded-md">
                      <span>策{stratCount}</span>
                      <span className="text-gray-200">|</span>
                      <span>动{actCount}</span>
                      <span className="text-gray-200">|</span>
                      <span>推{opCount}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick tips & user methodology board */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-indigo-200 p-4 rounded-2xl space-y-2.5 text-[11px] leading-relaxed shadow shadow-slate-200/50" id="tactical-tips-panel">
            <h4 className="font-bold text-white flex items-center gap-1 text-xs">
              <Compass className="w-4 h-4 text-indigo-400" />
              智库研究方法论看板
            </h4>
            <p className="text-indigo-300 font-normal">
              本智库的建立精髓在于<b>【打破行业蚕茧】</b>。点击社媒卡片右侧的 <b>[AI 联想]</b>，AI 会比对跨行业的玩法共通点（例如拿铁赠汝器与户外大篷车修鞋破洞的相同参与机制）。
            </p>
            <p className="text-indigo-300 font-normal">
              将这些零点颗粒勾选为<b>【灵感种子】</b>放入<b>【AI 梦工坊】</b>，即可快速定制产出顶尖的商业跨界案和微信排版草稿。
            </p>
          </div>
        </div>

        {/* Center / Right Main Area (Span 9) */}
        <div className="md:col-span-9 space-y-6" id="right-workspace-panel">
          
          {/* Main workspace mode selector tab list */}
          <div className="flex bg-white border border-gray-150 rounded-2xl p-1 shadow-sm gap-2" id="main-panel-tabs">
            <button
              onClick={() => setMainTab('explorer')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                mainTab === 'explorer'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              🗃️ 品牌研究工作台 (Workspace)
            </button>
            <button
              onClick={() => setMainTab('analytics')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                mainTab === 'analytics'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Atom className="w-4 h-4" />
              🌌 星宿图谱 & 🔮 AI 策划阁 (Map & AI Lab)
            </button>
          </div>

          {/* Conditional Work view rendering */}
          {mainTab === 'explorer' ? (
            <div className="space-y-4 animate-in fade-in duration-200">
              {currentSelectedBrand ? (
                <BrandDetail
                  brand={currentSelectedBrand}
                  strategies={data.strategies.filter(s => s.brandId === selectedBrandId)}
                  actions={data.actions.filter(a => a.brandId === selectedBrandId)}
                  operations={data.operations.filter(op => op.brandId === selectedBrandId)}
                  allData={data}
                  relationships={data.relationships}
                  selectedSeedIds={selectedSeeds.map(s => s.id)}
                  onToggleSeed={handleToggleSeed}
                  onSaveAiRelationship={handleSaveRelationship}
                  onAddStrategy={handleAddStrategyToData}
                  onAddAction={handleAddActionToData}
                  onAddOperation={handleAddOperationToData}
                  onUpdateCustomSections={handleUpdateCustomSections}
                  onUpdateBrand={handleUpdateBrandInfo}
                  onDeleteBrand={handleDeleteBrand}
                  onUpdateStrategy={handleUpdateStrategy}
                  onDeleteStrategy={handleDeleteStrategy}
                  onUpdateAction={handleUpdateAction}
                  onDeleteAction={handleDeleteAction}
                  onUpdateOperation={handleUpdateOperation}
                  onDeleteOperation={handleDeleteOperation}
                  focusItemId={focusItemId}
                  focusItemType={focusItemType}
                  setFocusItem={(id, type) => {
                    setFocusItemId(id);
                    setFocusItemType(type);
                  }}
                />
              ) : (
                <div className="py-16 bg-white border rounded-2xl text-center text-gray-400">
                  请在左侧侧边栏添加或选择一个你要分析的品牌。
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-200" id="analytics-workspace-panel">
              {/* AI Brainstorm Pilot Hub at TOP */}
              <CreativePilot
                selectedItems={selectedSeeds}
                onRemoveItem={handleRemoveSeed}
                onClearAll={handleClearSeeds}
              />

              {/* Network relationships SVG Mindmap at BOTTOM */}
              <ConnectionMap
                brands={data.brands}
                strategies={data.strategies}
                actions={data.actions}
                operations={data.operations}
                relationships={data.relationships}
                onSelectNode={handleJumpToNodeInWorkspace}
                onAddCustomRelation={handleCreateCustomRelation}
              />
            </div>
          )}
        </div>
      </main>

      {/* Footer Branding copy */}
      <footer className="border-t border-gray-150 py-6 mt-12 bg-white text-center text-[11px] text-gray-400 font-medium">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 品牌全球新媒体与策略研究智库 · AI 属地化共鸣引擎</p>
          <div className="flex gap-4">
            <span className="flex items-center gap-1.5 text-gray-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              本地多重存储已同步
            </span>
            <span className="text-gray-200">|</span>
            <span>搭载 Google GenAI @google/genai SDK v2.4+</span>
          </div>
        </div>
      </footer>

      {/* Add Custom Brand Builder Modal Drawer */}
      {showAddBrandModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-slate-50 border-b border-gray-150/50 p-5 flex items-center justify-between">
              <h3 className="text-sm font-bold text-gray-800 flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-indigo-600" />
                收录品牌进入观察库
              </h3>
              <button
                onClick={() => setShowAddBrandModal(false)}
                className="text-gray-400 hover:text-gray-600 font-extrabold text-lg"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddBrand} className="p-6 space-y-4">
              <div className="relative">
                <label className="block text-xs font-bold text-slate-700 mb-1.5">品牌名称 (含别名)*</label>
                <input
                  type="text"
                  required
                  value={newBName}
                  onChange={(e) => setNewBName(e.target.value)}
                  placeholder="例：Apple 苹果 或 蔚来 NIO"
                  className="w-full text-xs border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
                {isModalSuggesting && (
                  <div className="absolute right-3 top-8 text-[10px] text-indigo-600 animate-pulse font-medium">
                    匹配中...
                  </div>
                )}

                {/* Modal Auto-Search Suggestions Dropdown Panel */}
                {modalSuggestedBrands.length > 0 && (
                  <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-150 rounded-xl shadow-2xl z-50 overflow-hidden divide-y divide-gray-100 max-h-[160px] overflow-y-auto animate-in fade-in duration-100">
                    {modalSuggestedBrands.map((matchObj, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setNewBName(matchObj.name);
                          setNewBIndustry(matchObj.industry || '精品新零售');
                          setNewBLogoColor(matchObj.logoColor || 'bg-indigo-500');
                          setNewBDescription(matchObj.description || `自动分析建档品牌：${matchObj.name}。`);
                          setModalSuggestedBrands([]);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-slate-50 transition-colors flex items-center justify-between text-[11px] cursor-pointer"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={`w-2 h-2 rounded-full ${matchObj.logoColor || 'bg-indigo-500'} shrink-0`}></span>
                          <div className="min-w-0 leading-tight">
                            <span className="block font-bold text-gray-800 truncate">{matchObj.name}</span>
                            <span className="block text-[9px] text-gray-400 truncate mt-0.5">{matchObj.industry}</span>
                          </div>
                        </div>
                        <span className="text-[9px] bg-indigo-50 text-indigo-600 border border-indigo-100 font-extrabold px-1.5 py-0.5 rounded shrink-0">
                          点击选定并填充
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">行业赛道 / 垂类</label>
                  <input
                    type="text"
                    value={newBIndustry}
                    onChange={(e) => setNewBIndustry(e.target.value)}
                    placeholder="例：时尚零售 / 智能终端"
                    className="w-full text-xs border border-gray-200 rounded-lg px-3 py-2 outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">星图徽标辨识色</label>
                  <select
                    value={newBLogoColor}
                    onChange={(e) => setNewBLogoColor(e.target.value)}
                    className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-2 outline-none focus:border-indigo-500"
                  >
                    {brandColorsOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">品牌使命与核心商业主张*</label>
                <textarea
                  required={!autoAiEnrich}
                  rows={3}
                  value={newBDescription}
                  onChange={(e) => setNewBDescription(e.target.value)}
                  placeholder="该品牌倡导什么样的消费者价值观？它的核心爆款或门店体验是什么？"
                  className="w-full text-xs border border-gray-200 rounded-lg p-3 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed"
                ></textarea>
              </div>

              {/* AI Auto enriching switch */}
              <div className="bg-indigo-50/50 hover:bg-indigo-50 border border-indigo-100/50 p-2.5 rounded-xl flex items-start gap-2.5 transition-colors">
                <input
                  type="checkbox"
                  id="autoAiEnrichCheckbox"
                  checked={autoAiEnrich}
                  onChange={(e) => setAutoAiEnrich(e.target.checked)}
                  className="mt-0.5 h-3.5 w-3.5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="autoAiEnrichCheckbox" className="block text-[10px] text-slate-600 leading-normal select-none cursor-pointer">
                  <span className="font-bold text-indigo-700 block text-[11px] mb-0.5">自动联网检索补充完整品牌信息 (首选推荐)</span>
                  选中匹配品牌项或自定名称提交后，立刻由 AI 进行全球广域搜索与关联策略深度构建，自动补齐该品牌 2024~2026 年度的四季度的社媒汇报、标杆活动与产品等全量核心库。
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowAddBrandModal(false)}
                  className="text-xs border text-slate-500 font-bold px-4 py-2 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="text-xs bg-indigo-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-md cursor-pointer"
                >
                  {autoAiEnrich ? '智能搜寻并导入建档' : '手工导入观察库'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
