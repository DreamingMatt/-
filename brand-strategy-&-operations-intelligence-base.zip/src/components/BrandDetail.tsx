import React, { useState } from 'react';
import { Brand, AnnualStrategy, MarketingAction, NewMediaOperation, Relationship, RelationType } from '../types';
import {
  BookOpen,
  Calendar,
  Share2,
  Plus,
  CheckSquare,
  Sparkles,
  Link,
  ChevronRight,
  TrendingUp,
  BrainCircuit,
  Eye,
  Activity,
  PlusCircle,
  Clock,
  Edit2,
  Save,
  Trash2,
  Copy,
  Check,
  X
} from 'lucide-react';

interface BrandDetailProps {
  brand: Brand;
  strategies: AnnualStrategy[];
  actions: MarketingAction[];
  operations: NewMediaOperation[];
  allData: {
    brands: Brand[];
    strategies: AnnualStrategy[];
    actions: MarketingAction[];
    operations: NewMediaOperation[];
  };
  relationships: Relationship[];
  selectedSeedIds: string[];
  onToggleSeed: (id: string, type: 'strategy' | 'action' | 'operation', title: string, brandName: string, contentSummary: string) => void;
  onSaveAiRelationship: (rel: Relationship) => void;
  onAddStrategy: (strat: Omit<AnnualStrategy, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => void;
  onAddAction: (act: Omit<MarketingAction, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => void;
  onAddOperation: (op: Omit<NewMediaOperation, 'id' | 'createdAt'> & { id?: string; createdAt?: string }) => void;
  onUpdateCustomSections: (brandId: string, updatedSections: Array<{ id: string; title: string; content: string }>) => void;
  onUpdateBrand: (brandId: string, updated: Partial<Brand>) => void;
  onDeleteBrand: (brandId: string) => void;
  onUpdateStrategy: (strat: AnnualStrategy) => void;
  onDeleteStrategy: (stratId: string) => void;
  onUpdateAction: (act: MarketingAction) => void;
  onDeleteAction: (actId: string) => void;
  onUpdateOperation: (op: NewMediaOperation) => void;
  onDeleteOperation: (opId: string) => void;
  focusItemId: string | null;
  focusItemType: 'strategy' | 'action' | 'operation' | null;
  setFocusItem: (id: string | null, type: 'strategy' | 'action' | 'operation' | null) => void;
}

export default function BrandDetail({
  brand,
  strategies,
  actions,
  operations,
  allData,
  relationships,
  selectedSeedIds,
  onToggleSeed,
  onSaveAiRelationship,
  onAddStrategy,
  onAddAction,
  onAddOperation,
  onUpdateCustomSections,
  onUpdateBrand,
  onDeleteBrand,
  onUpdateStrategy,
  onDeleteStrategy,
  onUpdateAction,
  onDeleteAction,
  onUpdateOperation,
  onDeleteOperation,
  focusItemId,
  focusItemType,
  setFocusItem
}: BrandDetailProps) {
  const [activeTab, setActiveTab] = useState<'strategy' | 'action' | 'operation' | 'custom'>('strategy');
  const [selectedYear, setSelectedYear] = useState<number | 'all'>('all');
  
  // Brand Profile Inline Edit states
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editBName, setEditBName] = useState(brand.name);
  const [editBIndustry, setEditBIndustry] = useState(brand.industry);
  const [editBDescription, setEditBDescription] = useState(brand.description);
  const [editBLogoColor, setEditBLogoColor] = useState(brand.logoColor);

  // Synchronize when brand changes
  React.useEffect(() => {
    setEditBName(brand.name);
    setEditBIndustry(brand.industry);
    setEditBDescription(brand.description);
    setEditBLogoColor(brand.logoColor);
    setIsEditingProfile(false);
  }, [brand]);

  // Strategy Edit states
  const [editingStrategyId, setEditingStrategyId] = useState<string | null>(null);
  const [editStrategyData, setEditStrategyData] = useState<AnnualStrategy | null>(null);

  // Marketing Action Edit states
  const [editingActionId, setEditingActionId] = useState<string | null>(null);
  const [editActionData, setEditActionData] = useState<MarketingAction | null>(null);

  // Social Media Post Edit states
  const [editingOperationId, setEditingOperationId] = useState<string | null>(null);
  const [editOperationData, setEditOperationData] = useState<NewMediaOperation | null>(null);

  // Duplicate controllers that instantly start in edit mode with exact same data layout (cloning identical templates)
  const handleCloneStrategy = (strat: AnnualStrategy) => {
    const clonedId = `strat-${Date.now()}`;
    const cloned: Omit<AnnualStrategy, 'id' | 'createdAt'> = {
      brandId: strat.brandId,
      year: strat.year,
      tagline: `${strat.tagline} (复制模板)`,
      keywords: [...strat.keywords],
      targetAudience: strat.targetAudience,
      coreFocus: strat.coreFocus,
      revenueInfo: strat.revenueInfo,
      storeCountInfo: strat.storeCountInfo,
      keyProductsInfo: strat.keyProductsInfo
    };
    onAddStrategy({ ...cloned, id: clonedId });
    setEditingStrategyId(clonedId);
    setEditStrategyData({
      id: clonedId,
         brandId: strat.brandId,
         year: strat.year,
      tagline: `${strat.tagline} (复制模板)`,
      keywords: [...strat.keywords],
      targetAudience: strat.targetAudience,
      coreFocus: strat.coreFocus,
      revenueInfo: strat.revenueInfo,
      storeCountInfo: strat.storeCountInfo,
      keyProductsInfo: strat.keyProductsInfo
    });
  };

  const handleCloneAction = (act: MarketingAction) => {
    const clonedId = `act-${Date.now()}`;
    const cloned: Omit<MarketingAction, 'id' | 'createdAt'> = {
      brandId: act.brandId,
      title: `${act.title} (复制模板)`,
      date: act.date,
      type: act.type,
      description: act.description,
      channels: [...act.channels],
      results: act.results,
      quarter: act.quarter,
      quarterlySummary: act.quarterlySummary,
      newProducts: act.newProducts
    };
    onAddAction({ ...cloned, id: clonedId });
    setEditingActionId(clonedId);
    setEditActionData({
      id: clonedId,
      brandId: act.brandId,
      title: `${act.title} (复制模板)`,
      date: act.date,
      type: act.type,
      description: act.description,
      channels: [...act.channels],
      results: act.results,
      quarter: act.quarter,
      quarterlySummary: act.quarterlySummary,
      newProducts: act.newProducts
    });
  };

  const handleCloneOperation = (op: NewMediaOperation) => {
    const clonedId = `op-${Date.now()}`;
    const cloned: Omit<NewMediaOperation, 'id' | 'createdAt'> = {
      brandId: op.brandId,
      platform: op.platform,
      accountName: op.accountName,
      postTitle: `${op.postTitle} (复制模板)`,
      postContent: op.postContent,
      visualStyle: op.visualStyle,
      postDate: op.postDate,
      interactionCount: op.interactionCount,
      quarter: op.quarter,
      isQuarterlySummary: op.isQuarterlySummary,
      platformsIntel: op.platformsIntel ? op.platformsIntel.map(p => ({ ...p })) : undefined
    };
    onAddOperation({ ...cloned, id: clonedId });
    setEditingOperationId(clonedId);
    setEditOperationData({
      id: clonedId,
      brandId: op.brandId,
      platform: op.platform,
      accountName: op.accountName,
      postTitle: `${op.postTitle} (复制模板)`,
      postContent: op.postContent,
      visualStyle: op.visualStyle,
      postDate: op.postDate,
      interactionCount: op.interactionCount,
      quarter: op.quarter,
      isQuarterlySummary: op.isQuarterlySummary,
      platformsIntel: op.platformsIntel ? op.platformsIntel.map(p => ({ ...p })) : undefined
    });
  };

  const handleCreateBlankStrategy = () => {
    const newId = `strat-${Date.now()}`;
    const yearVal = selectedYear === 'all' ? 2026 : Number(selectedYear);
    const blank: Omit<AnnualStrategy, 'id' | 'createdAt'> = {
      brandId: brand.id,
      year: yearVal,
      tagline: '新建品牌策略标题',
      keywords: ['新标签'],
      targetAudience: '目标人群描述',
      coreFocus: '在这里描述该策略的落点方向和创意核心要素...'
    };
    onAddStrategy({ ...blank, id: newId });
    setEditingStrategyId(newId);
    setEditStrategyData({
      id: newId,
      brandId: brand.id,
      year: yearVal,
      tagline: '新建品牌策略标题',
      keywords: ['新标签'],
      targetAudience: '目标人群描述',
      coreFocus: '在这里描述该策略的落点方向和创意核心要素...'
    });
  };

  const handleCreateBlankAction = () => {
    const newId = `act-${Date.now()}`;
    const blank: Omit<MarketingAction, 'id' | 'createdAt'> = {
      brandId: brand.id,
      title: '新建营销战役动作名称',
      date: new Date().toISOString().split('T')[0],
      type: '联名合作',
      description: '请在这里详情陈述这次营销战役的背景、活动主体和联名链路玩法...',
      channels: ['小红书', '微信'],
      results: '写下该项动作的战役成效与量化研判概括...'
    };
    onAddAction({ ...blank, id: newId });
    setEditingActionId(newId);
    setEditActionData({
      id: newId,
      brandId: brand.id,
      title: '新建营销战役动作名称',
      date: new Date().toISOString().split('T')[0],
      type: '联名合作',
      description: '请在这里详情陈述这次营销战役的背景、活动主体和联名链路玩法...',
      channels: ['小红书', '微信'],
      results: '写下该项动作的战役成效与量化研判概括...'
    });
  };

  const handleCreateBlankOperation = () => {
    const newId = `op-${Date.now()}`;
    const blank: Omit<NewMediaOperation, 'id' | 'createdAt'> = {
      brandId: brand.id,
      platform: 'Red',
      accountName: '官方小红书自营号',
      postTitle: '写一个新推文标题',
      postContent: '写下推文的排版、文案以及引流或互动细究草稿信息...',
      visualStyle: '视觉海报/色度摄影配图风格分析...',
      postDate: new Date().toISOString().split('T')[0],
      interactionCount: '点赞 0, 评论 0'
    };
    onAddOperation({ ...blank, id: newId });
    setEditingOperationId(newId);
    setEditOperationData({
      id: newId,
      brandId: brand.id,
      platform: 'Red',
      accountName: '官方小红书自营号',
      postTitle: '写一个新推文标题',
      postContent: '写下推文的排版、文案以及引流或互动细究草稿信息...',
      visualStyle: '视觉海报/色度摄影配图风格分析...',
      postDate: new Date().toISOString().split('T')[0],
      interactionCount: '点赞 0, 评论 0'
    });
  };

  // Custom Addition Forms Toggle and States
  const [showAddForm, setShowAddForm] = useState(false);
  
  // Custom Section states
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);
  const [newCTitle, setNewCTitle] = useState('');
  const [newCContent, setNewCContent] = useState('');

  // New Strategy States
  const [newSYear, setNewSYear] = useState(2026);
  const [newSTagline, setNewSTagline] = useState('');
  const [newSKeywords, setNewSKeywords] = useState('');
  const [newSTarget, setNewSTarget] = useState('');
  const [newSFocus, setNewSFocus] = useState('');

  // New Action States
  const [newATitle, setNewATitle] = useState('');
  const [newADate, setNewADate] = useState(new Date().toISOString().split('T')[0]);
  const [newAType, setNewAType] = useState('联名合作');
  const [newADesc, setNewADesc] = useState('');
  const [newAChannels, setNewAChannels] = useState('小红书, 微信');
  const [newAResults, setNewAResults] = useState('');

  // New Operation States
  const [newOPlatform, setNewOPlatform] = useState<'Red' | 'Weixin' | 'Weibo' | 'Douyin' | 'Bilibili' | 'Other'>('Red');
  const [newOAccountName, setNewOAccountName] = useState('');
  const [newOPostTitle, setNewOPostTitle] = useState('');
  const [newOPostContent, setNewOPostContent] = useState('');
  const [newOVisualStyle, setNewOVisualStyle] = useState('');
  const [newOPostDate, setNewOPostDate] = useState(new Date().toISOString().split('T')[0]);
  const [newOInteraction, setNewOInteraction] = useState('点赞2.3k, 评论240');

  // AI Association states
  const [analyzingItem, setAnalyzingItem] = useState<any | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState<any[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Load an item to run association analysis
  const handleLoadToAnalyzer = (item: any, type: 'strategy' | 'action' | 'operation') => {
    setFocusItem(item.id, type);
    setAnalyzingItem({
      ...item,
      itemType: type,
      brandName: brand.name
    });
    setAiSuggestions([]);
    setAiError(null);
  };

  // Run AI Association matching
  const handleRunAiAssociation = async () => {
    if (!analyzingItem) return;
    
    setIsAiLoading(true);
    setAiError(null);
    setAiSuggestions([]);

    try {
      // Assemble all other items in the database that Gemini could reference
      const otherItems: any[] = [];
      
      allData.strategies.forEach(s => {
        if (s.id === analyzingItem.id) return;
        const b = allData.brands.find(br => br.id === s.brandId);
        otherItems.push({
          id: s.id,
          brandId: s.brandId,
          brandName: b?.name || '其他品牌',
          type: 'strategy',
          tagline: s.tagline,
          keywords: s.keywords,
          coreFocus: s.coreFocus
        });
      });

      allData.actions.forEach(a => {
        if (a.id === analyzingItem.id) return;
        const b = allData.brands.find(br => br.id === a.brandId);
        otherItems.push({
          id: a.id,
          brandId: a.brandId,
          brandName: b?.name || '其他品牌',
          type: 'action',
          title: a.title,
          description: a.description,
          actionType: a.type
        });
      });

      allData.operations.forEach(o => {
        if (o.id === analyzingItem.id) return;
        const b = allData.brands.find(br => br.id === o.brandId);
        otherItems.push({
          id: o.id,
          brandId: o.brandId,
          brandName: b?.name || '其他品牌',
          type: 'operation',
          platform: o.platform,
          postTitle: o.postTitle,
          postContent: o.postContent,
          visualStyle: o.visualStyle
        });
      });

      const response = await fetch("/api/brand/associate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentItem: analyzingItem,
          otherItems: otherItems
        })
      });

      if (!response.ok) {
        throw new Error(`AI联想服务无响应: ${response.status}`);
      }

      const resData = await response.json();
      if (resData.error) {
        throw new Error(resData.error);
      }

      setAiSuggestions(resData.suggestions || []);
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "无法完成AI联想分析");
    } finally {
      setIsAiLoading(false);
    }
  };

  // Save the suggested AI relationship to active library
  const handleSaveAssociation = (sugg: any) => {
    if (!analyzingItem) return;

    const sourceTitle = analyzingItem.title || analyzingItem.postTitle || analyzingItem.tagline || '素材A';
    
    const newRel: Relationship = {
      id: `rel-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      sourceId: analyzingItem.id,
      sourceType: analyzingItem.itemType,
      sourceTitle: `${sourceTitle.slice(0, 35)}... (${analyzingItem.itemType === 'strategy' ? '策略' : analyzingItem.itemType === 'action' ? '行动' : '帖子'})`,
      sourceBrandName: brand.name,
      
      targetId: sugg.targetId,
      targetType: sugg.targetType,
      targetTitle: sugg.targetTitle,
      targetBrandName: sugg.targetBrandName,
      
      relationType: sugg.relationType,
      description: sugg.description,
      confidence: sugg.confidence || 0.85,
      isAiGenerated: true
    };

    onSaveAiRelationship(newRel);
    
    // Auto remove saved items from suggested lists so they can't save twice
    setAiSuggestions(prev => prev.filter(item => item.targetId !== sugg.targetId));
    alert(`成功将该联系写入 品牌关联星图 💡 现在可在下方星图看到该星轨曲线！`);
  };

  // Submit handers
  const handleSubmitStrategy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSTagline || !newSFocus) {
      alert("请填写年度核心标语及策略重点。");
      return;
    }
    onAddStrategy({
      brandId: brand.id,
      year: Number(newSYear),
      tagline: newSTagline,
      keywords: newSKeywords.split(/[,，]/).map(k => k.trim()).filter(Boolean),
      targetAudience: newSTarget,
      coreFocus: newSFocus
    });
    setNewSTagline('');
    setNewSKeywords('');
    setNewSTarget('');
    setNewSFocus('');
    setShowAddForm(false);
  };

  const handleSubmitAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newATitle || !newADesc) {
      alert("请填写活动名称和详情。");
      return;
    }
    onAddAction({
      brandId: brand.id,
      title: newATitle,
      date: newADate,
      type: newAType,
      description: newADesc,
      channels: newAChannels.split(/[,，]/).map(c => c.trim()).filter(Boolean),
      results: newAResults
    });
    setNewATitle('');
    setNewADesc('');
    setNewAResults('');
    setShowAddForm(false);
  };

  const handleSubmitOperation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOPostTitle || !newOPostContent) {
      alert("请填写推文标题及详细文案内容。");
      return;
    }
    onAddOperation({
      brandId: brand.id,
      platform: newOPlatform,
      accountName: newOAccountName || brand.name,
      postTitle: newOPostTitle,
      postContent: newOPostContent,
      visualStyle: newOVisualStyle,
      postDate: newOPostDate,
      interactionCount: newOInteraction
    });
    setNewOPostTitle('');
    setNewOPostContent('');
    setNewOVisualStyle('');
    setNewOAccountName('');
    setShowAddForm(false);
  };

  const handleAddCustomSection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCTitle || !newCContent) {
      alert("请填写类目名称和详细内容。");
      return;
    }
    const currentCustom = brand.customSections || [];
    const newSection = {
      id: `custom-${Date.now()}`,
      title: newCTitle,
      content: newCContent
    };
    onUpdateCustomSections(brand.id, [...currentCustom, newSection]);
    setNewCTitle('');
    setNewCContent('');
    setShowAddForm(false);
  };

  const handleSaveEditedCustomSection = (id: string, updatedTitle: string, updatedContent: string) => {
    if (!updatedTitle || !updatedContent) {
      alert("类目标题和细分内容均不能为空。");
      return;
    }
    const currentCustom = brand.customSections || [];
    const updated = currentCustom.map(sec => 
      sec.id === id ? { ...sec, title: updatedTitle, content: updatedContent } : sec
    );
    onUpdateCustomSections(brand.id, updated);
    setEditingSectionId(null);
  };

  const handleDeleteCustomSection = (id: string) => {
    const currentCustom = brand.customSections || [];
    const filtered = currentCustom.filter(sec => sec.id !== id);
    onUpdateCustomSections(brand.id, filtered);
  };

  // Find relationships linked to the focus item
  const linkedRelationships = relationships.filter(
    rel => (rel.sourceId === focusItemId) || (rel.targetId === focusItemId)
  );

  const cardSelectedBorder = (id: string) => 
    focusItemId === id ? 'border-2 border-indigo-600 ring-2 ring-indigo-50/50 bg-indigo-50/20' : 'border-gray-100 hover:border-indigo-200';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="brand-detail-panel">
      {/* Brand Workspace Dashboard (Left/Center col - span 7) */}
      <div className="lg:col-span-7 flex flex-col justify-between space-y-5">
        <div>
          {/* Brand header */}
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 shadow-sm" id="brand-workspace-header">
            {isEditingProfile ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onUpdateBrand(brand.id, {
                    name: editBName,
                    industry: editBIndustry,
                    description: editBDescription,
                    logoColor: editBLogoColor
                  });
                  setIsEditingProfile(false);
                }}
                className="space-y-3.5"
              >
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">编辑品牌名称</label>
                    <input
                      type="text"
                      value={editBName}
                      onChange={(e) => setEditBName(e.target.value)}
                      required
                      className="w-full text-xs font-bold border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">编辑行业分类</label>
                    <input
                      type="text"
                      value={editBIndustry}
                      onChange={(e) => setEditBIndustry(e.target.value)}
                      required
                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">编辑核心故事和商业定位描述</label>
                  <textarea
                    value={editBDescription}
                    onChange={(e) => setEditBDescription(e.target.value)}
                    required
                    rows={3}
                    className="w-full text-xs border border-gray-200 rounded p-2 bg-white text-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none font-normal"
                  ></textarea>
                </div>

                <div className="flex items-center justify-between gap-3 border-t border-gray-150 pt-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-500 font-bold">品牌基调色：</span>
                    <div className="flex gap-1">
                      {['bg-indigo-500', 'bg-emerald-500', 'bg-amber-500', 'bg-rose-500', 'bg-lime-500', 'bg-sky-500'].map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => setEditBLogoColor(color)}
                          className={`w-4.5 h-4.5 rounded-full border ${color} ${editBLogoColor === color ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : 'opacity-70 hover:opacity-100'}`}
                        ></button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`⚠️ 确定要彻底删除品牌「${brand.name}」吗？\n删除后该品牌下所有的「年度策略」、「营销战役动作」、「社媒推文发帖」以及所有的「AI星宿图谱关联关系」都将一并彻底被清空！此操作不可逆，请谨慎确认。`)) {
                          onDeleteBrand(brand.id);
                        }
                      }}
                      className="px-2.5 py-1 text-xs font-bold bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded flex items-center gap-1 cursor-pointer mr-auto"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                      删除此品牌
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setEditBName(brand.name);
                        setEditBIndustry(brand.industry);
                        setEditBDescription(brand.description);
                        setEditBLogoColor(brand.logoColor);
                        setIsEditingProfile(false);
                      }}
                      className="px-2.5 py-1 border border-slate-200 hover:bg-slate-50 rounded text-slate-500 text-xs font-semibold cursor-pointer"
                    >
                      取消
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-bold shadow flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      保存品牌信息
                    </button>
                  </div>
                </div>
              </form>
            ) : (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className={`w-3.5 h-3.5 rounded-full ${brand.logoColor} shrink-0`}></span>
                    <h1 className="text-xl font-bold text-slate-800 tracking-tight">{brand.name}</h1>
                    <span className="text-[11px] font-bold text-gray-500 bg-white border border-gray-100 px-2.5 py-0.5 rounded-full">
                      {brand.industry}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsEditingProfile(true)}
                      className="text-xs font-semibold bg-white border border-gray-200 text-gray-700 hover:text-indigo-600 hover:bg-gray-50 flex items-center gap-1 px-2.5 py-1.5 rounded-lg shadow-sm transition-colors cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3 text-slate-500" />
                      编辑品牌
                    </button>

                    <button
                      onClick={() => setShowAddForm(!showAddForm)}
                      className="text-xs font-semibold bg-white border border-gray-200 text-gray-700 hover:text-indigo-600 hover:bg-gray-50 flex items-center gap-1.5 px-3 py-1.5 rounded-lg shadow-sm transition-colors cursor-pointer"
                    >
                      <PlusCircle className="w-3.5 h-3.5 text-indigo-500" />
                      写笔记收录新内容
                    </button>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2.5 leading-relaxed font-normal">{brand.description}</p>
              </div>
            )}
          </div>

          {/* Quick interactive note form container */}
          {showAddForm && (
            <div className="bg-amber-50/45 border-2 border-dashed border-amber-200 rounded-2xl p-5 mt-4 animate-in slide-in-from-top-3 duration-250">
              <div className="flex items-center justify-between border-b border-amber-200/50 pb-3 mb-4">
                <span className="text-xs font-bold text-amber-800 tracking-wide flex items-center gap-1">
                  <Activity className="w-4 h-4 text-amber-600" />
                    手写研究素材收录
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="text-amber-700 hover:text-amber-900 text-lg font-bold"
                >
                  &times;
                </button>
              </div>

              {/* Form Tab Toggles */}
              <div className="flex flex-wrap bg-amber-100/50 p-1 rounded-lg gap-1 mb-4" id="form-tab-triggers">
                <button
                  type="button"
                  onClick={() => setActiveTab('strategy')}
                  className={`flex-1 min-w-[70px] text-[10px] font-bold py-1.5 rounded-md text-center transition-all ${
                    activeTab === 'strategy' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  年度品牌策略
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('action')}
                  className={`flex-1 min-w-[70px] text-[10px] font-bold py-1.5 rounded-md text-center transition-all ${
                    activeTab === 'action' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  营销战役动作
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('operation')}
                  className={`flex-1 min-w-[70px] text-[10px] font-bold py-1.5 rounded-md text-center transition-all ${
                    activeTab === 'operation' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  社媒推文细节
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('custom')}
                  className={`flex-1 min-w-[70px] text-[10px] font-bold py-1.5 rounded-md text-center transition-all ${
                    activeTab === 'custom' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  专有补充类目
                </button>
              </div>

              {/* Annual strategy formulation */}
              {activeTab === 'strategy' && (
                <form onSubmit={handleSubmitStrategy} className="space-y-3.5">
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">策略对应年份</label>
                      <input
                        type="number"
                        required
                        value={newSYear}
                        onChange={(e) => setNewSYear(Number(e.target.value))}
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2 py-1.5 text-slate-800"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">主线标语 (Tagline)*</label>
                      <input
                        type="text"
                        required
                        value={newSTagline}
                        onChange={(e) => setNewSTagline(e.target.value)}
                        placeholder="例：找到你的身心重心"
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">策略核心关键词 (用逗号分隔)</label>
                    <input
                      type="text"
                      value={newSKeywords}
                      onChange={(e) => setNewSKeywords(e.target.value)}
                      placeholder="例：身心健康, 热汗社群, 属地化共鸣"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">研判受众群体</label>
                    <input
                      type="text"
                      value={newSTarget}
                      onChange={(e) => setNewSTarget(e.target.value)}
                      placeholder="例：一二线白领、情绪自愈追求者"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">年度策略核心落地方向描述*</label>
                    <textarea
                      required
                      rows={3}
                      value={newSFocus}
                      onChange={(e) => setNewSFocus(e.target.value)}
                      placeholder="描述其年度如何通过不同内容形式、渠道定位、线下服务去重塑这个品牌大概念..."
                      className="w-full text-xs bg-white border border-amber-200/60 rounded p-2 text-slate-800 resize-none"
                    ></textarea>
                  </div>
                  <button type="submit" className="w-full text-xs bg-amber-600 hover:bg-amber-700 text-white font-bold py-1.5 rounded shadow cursor-pointer">
                    保存策略至基库
                  </button>
                </form>
              )}

              {/* Marketing actions formulation */}
              {activeTab === 'action' && (
                <form onSubmit={handleSubmitAction} className="space-y-3.5">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">营销战役名称*</label>
                      <input
                        type="text"
                        required
                        value={newATitle}
                        onChange={(e) => setNewATitle(e.target.value)}
                        placeholder="例：地球日自带杯免费送"
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">落地发起时间</label>
                      <input
                        type="date"
                        required
                        value={newADate}
                        onChange={(e) => setNewADate(e.target.value)}
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">活动分类属性</label>
                      <input
                        type="text"
                        value={newAType}
                        onChange={(e) => setNewAType(e.target.value)}
                        placeholder="例：环保公益 / 裂变促销 / 联名合作"
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">全网发布渠道</label>
                      <input
                        type="text"
                        value={newAChannels}
                        onChange={(e) => setNewAChannels(e.target.value)}
                        placeholder="微信, 小红书, 微博"
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">关键动作与底层机制剖析*</label>
                    <textarea
                      required
                      rows={3}
                      value={newADesc}
                      onChange={(e) => setNewADesc(e.target.value)}
                      placeholder="用户怎么玩？有什么买赠或精神仪式？有无联名？"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded p-2 text-slate-800 resize-none"
                    ></textarea>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">研判或收获的数据指标/亮点反馈</label>
                    <input
                      type="text"
                      value={newAResults}
                      onChange={(e) => setNewAResults(e.target.value)}
                      placeholder="例：排队500米，小红书新增4000条笔记"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <button type="submit" className="w-full text-xs bg-amber-600 hover:bg-amber-700 text-white font-bold py-1.5 rounded shadow cursor-pointer">
                    保存战役动作
                  </button>
                </form>
              )}

              {/* Social media operations formulation */}
              {activeTab === 'operation' && (
                <form onSubmit={handleSubmitOperation} className="space-y-3.5">
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">推文平台</label>
                      <select
                        value={newOPlatform}
                        onChange={(e) => setNewOPlatform(e.target.value as any)}
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2 py-1.5 text-slate-800"
                      >
                        <option value="Red">小红书 (Red)</option>
                        <option value="Weixin">微信 (Weixin)</option>
                        <option value="Weibo">微博 (Weibo)</option>
                        <option value="Douyin">抖音 (Douyin)</option>
                        <option value="Bilibili">B站 (Bilibili)</option>
                        <option value="Other">其他论坛 (Other)</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">推文首行爆款标题*</label>
                      <input
                        type="text"
                        required
                        value={newOPostTitle}
                        onChange={(e) => setNewOPostTitle(e.target.value)}
                        placeholder="例：大森林的薄荷绿，吸一口一秒松弛！🌿"
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">发布账号名称</label>
                      <input
                        type="text"
                        value={newOAccountName}
                        onChange={(e) => setNewOAccountName(e.target.value)}
                        placeholder={`默认：${brand.name}`}
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 mb-1">发布日期</label>
                      <input
                        type="date"
                        value={newOPostDate}
                        onChange={(e) => setNewOPostDate(e.target.value)}
                        className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">视觉创意及海报排版风格细究</label>
                    <input
                      type="text"
                      value={newOVisualStyle}
                      onChange={(e) => setNewOVisualStyle(e.target.value)}
                      placeholder="例：清晨日光感的自然色调摄影，宋瓷天青冰釉特写"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">推文内嵌文案/文网/ emoji 实录内容*</label>
                    <textarea
                      required
                      rows={4}
                      value={newOPostContent}
                      onChange={(e) => setNewOPostContent(e.target.value)}
                      placeholder="粘贴博主/官号发布的话术草稿，包括 #Tag 和相关引流操作..."
                      className="w-full text-xs bg-white border border-amber-200/60 rounded p-2 text-slate-800 resize-none font-mono"
                    ></textarea>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">记录时的互动热度数据</label>
                    <input
                      type="text"
                      value={newOInteraction}
                      onChange={(e) => setNewOInteraction(e.target.value)}
                      placeholder="例：点赞 1.2w | 收藏 4k | 评论 522"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <button type="submit" className="w-full text-xs bg-amber-600 hover:bg-amber-700 text-white font-bold py-1.5 rounded shadow cursor-pointer">
                    保存推文内容
                  </button>
                </form>
              )}

              {/* Custom supplementary category formulation */}
              {activeTab === 'custom' && (
                <form onSubmit={handleAddCustomSection} className="space-y-3.5">
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">类目名称 / 研究领域*</label>
                    <input
                      type="text"
                      required
                      value={newCTitle}
                      onChange={(e) => setNewCTitle(e.target.value)}
                      placeholder="例：上下游供应链优势 或 核心痛点研判"
                      className="w-full text-xs bg-white border border-amber-200/60 rounded px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-800 mb-1">内容详情记录* (支持任意格式文本)</label>
                    <textarea
                      required
                      rows={4}
                      value={newCContent}
                      onChange={(e) => setNewCContent(e.target.value)}
                      placeholder="写下你针对该品牌这一类目维度的详细分析、补充研习资料..."
                      className="w-full text-xs bg-white border border-amber-200/60 rounded p-2 text-slate-800 resize-none"
                    ></textarea>
                  </div>
                  <button type="submit" className="w-full text-xs bg-amber-600 hover:bg-amber-700 text-white font-bold py-1.5 rounded shadow cursor-pointer">
                    保存专属补充研判
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Brand dynamic Year Selection filter bar */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-white border border-slate-100 p-3 rounded-2xl gap-3 mt-4" id="year-filter-and-tabs">
            <span className="text-[11px] font-extrabold text-slate-500 flex items-center gap-1.5 shrink-0 uppercase tracking-widest">
              <Calendar className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              年度标签分类：
            </span>
            <div className="flex flex-wrap bg-slate-50 border border-slate-100 p-0.5 rounded-xl gap-0.5">
              {([2026, 2025, 2024, 'all'] as const).map((yr) => (
                <button
                  key={yr}
                  onClick={() => setSelectedYear(yr)}
                  className={`text-[10px] font-bold px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    selectedYear === yr
                      ? 'bg-white text-indigo-600 shadow-sm border border-slate-200/40 font-extrabold'
                      : 'text-gray-400 hover:text-gray-600 border border-transparent'
                  }`}
                >
                  {yr === 'all' ? '全部年份' : `${yr} 年`}
                </button>
              ))}
            </div>
          </div>

          {/* Core content category tabs */}
          <div className="flex bg-slate-100 p-1.5 rounded-xl gap-2 mt-5" id="brand-content-tabs-bar">
            {(['strategy', 'action', 'operation', 'custom'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setAnalyzingItem(null);
                  setAiSuggestions([]);
                }}
                className={`flex-1 text-[11px] py-2 rounded-lg font-bold tracking-wide text-center transition-all cursor-pointer ${
                  activeTab === tab
                    ? 'bg-white text-slate-800 shadow shadow-slate-100/60'
                    : 'text-gray-500 hover:text-gray-900 font-medium'
                }`}
              >
                {tab === 'strategy' ? '🌐 年度策略' : tab === 'action' ? '🚀 营销活动' : tab === 'operation' ? '📱 社媒帖子' : '✏️ 专有类目'}
              </button>
            ))}
          </div>

          {/* Cards feed output */}
          <div className="space-y-4 mt-5 max-h-[580px] overflow-y-auto pr-2" id="brand-cards-feed">
            {/* 1. STRATEGIES FEED */}
            {activeTab === 'strategy' && (
              (() => {
                const visibleStrats = strategies.filter(s => selectedYear === 'all' || s.year === selectedYear);
                return (
                  <div className="space-y-4">
                    {visibleStrats.length > 0 ? (
                      visibleStrats.map((strat) => {
                        const isSeed = selectedSeedIds.includes(strat.id);
                        return (
                          <div
                            key={strat.id}
                            className={`relative bg-white border p-5 rounded-2xl shadow-sm transition-all flex flex-col ${cardSelectedBorder(strat.id)}`}
                          >
                            {editingStrategyId === strat.id ? (
                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  if (editStrategyData) {
                                    onUpdateStrategy(editStrategyData);
                                  }
                                  setEditingStrategyId(null);
                                  setEditStrategyData(null);
                                }}
                                className="space-y-4"
                              >
                                <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                                  <span className="text-xs font-extrabold text-indigo-700 flex items-center gap-1">
                                    <Edit2 className="w-3.5 h-3.5" /> 编辑年度策略
                                  </span>
                                  <div className="flex gap-2">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        onDeleteStrategy(strat.id);
                                        setEditingStrategyId(null);
                                        setEditStrategyData(null);
                                      }}
                                      className="text-xs bg-rose-50 hover:bg-rose-100 text-rose-600 px-2.5 py-1 rounded font-semibold flex items-center gap-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      删除此策略
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingStrategyId(null);
                                        setEditStrategyData(null);
                                      }}
                                      className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-500 px-2.5 py-1 rounded font-semibold cursor-pointer"
                                    >
                                      取消
                                    </button>
                                    <button
                                      type="submit"
                                      className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded font-bold flex items-center gap-1 cursor-pointer shadow-sm"
                                    >
                                      <Save className="w-3.5 h-3.5" />
                                      保存
                                    </button>
                                  </div>
                                </div>

                                <div className="grid grid-cols-3 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">策略年度 (Year)</label>
                                    <input
                                      type="number"
                                      value={editStrategyData?.year || 2026}
                                      onChange={(e) => setEditStrategyData(p => p ? { ...p, year: Number(e.target.value) } : null)}
                                      required
                                      className="w-full text-xs font-semibold border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div className="col-span-2">
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">主线标语 / 策略口号 (Tagline)</label>
                                    <input
                                      type="text"
                                      value={editStrategyData?.tagline || ''}
                                      onChange={(e) => setEditStrategyData(p => p ? { ...p, tagline: e.target.value } : null)}
                                      required
                                      className="w-full text-xs font-bold border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">核心关键词 (逗号英文分隔)</label>
                                    <input
                                      type="text"
                                      value={editStrategyData?.keywords.join(', ') || ''}
                                      onChange={(e) => setEditStrategyData(p => p ? { ...p, keywords: e.target.value.split(',').map(s => s.trim()).filter(Boolean) } : null)}
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">目标受众群体 (Target Audience)</label>
                                    <input
                                      type="text"
                                      value={editStrategyData?.targetAudience || ''}
                                      onChange={(e) => setEditStrategyData(p => p ? { ...p, targetAudience: e.target.value } : null)}
                                      required
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 mb-1">核心落合方向与要点阐述 (Core Focus)</label>
                                  <textarea
                                    value={editStrategyData?.coreFocus || ''}
                                    onChange={(e) => setEditStrategyData(p => p ? { ...p, coreFocus: e.target.value } : null)}
                                    required
                                    rows={3}
                                    className="w-full text-xs border border-gray-200 rounded p-2 bg-white text-slate-800 font-normal resize-none"
                                  ></textarea>
                                </div>

                                <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl space-y-3">
                                  <span className="text-[10px] font-extrabold text-slate-500 tracking-wide block">
                                    📊 年度财报核心提要（财富/开店与爆款提炼，选填）
                                  </span>
                                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 px-1">
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-400 mb-1">营收及利润概况</label>
                                      <input
                                        type="text"
                                        value={editStrategyData?.revenueInfo || ''}
                                        onChange={(e) => setEditStrategyData(p => p ? { ...p, revenueInfo: e.target.value } : null)}
                                        placeholder="例如：财年营收大增"
                                        className="w-full text-[10px] border border-gray-100 rounded p-1.5 bg-white text-slate-700 font-normal"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-400 mb-1">规模与开店变动</label>
                                      <input
                                        type="text"
                                        value={editStrategyData?.storeCountInfo || ''}
                                        onChange={(e) => setEditStrategyData(p => p ? { ...p, storeCountInfo: e.target.value } : null)}
                                        placeholder="例如：总计门店突破"
                                        className="w-full text-[10px] border border-gray-100 rounded p-1.5 bg-white text-slate-700 font-normal"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-400 mb-1">主打爆品与毛利带</label>
                                      <input
                                        type="text"
                                        value={editStrategyData?.keyProductsInfo || ''}
                                        onChange={(e) => setEditStrategyData(p => p ? { ...p, keyProductsInfo: e.target.value } : null)}
                                        placeholder="例如：轻冲锋衣占据爆款"
                                        className="w-full text-[10px] border border-gray-100 rounded p-1.5 bg-white text-slate-700 font-normal"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </form>
                            ) : (
                              <>
                                {/* Control buttons inside header */}
                                <div className="flex items-start justify-between gap-3 pb-3 border-b border-gray-100/60">
                                  <div className="flex flex-wrap items-center gap-1.5">
                                    <span className="text-[10px] font-extrabold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full">
                                      {strat.year}年度策略
                                    </span>

                                    <button
                                      onClick={() => {
                                        setEditingStrategyId(strat.id);
                                        setEditStrategyData({ ...strat });
                                      }}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50"
                                    >
                                      <Edit2 className="w-3.5 h-3.5" />
                                      编辑
                                    </button>

                                    <button
                                      onClick={() => handleCloneStrategy(strat)}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50"
                                      title="以此案模板复制一个完全相同待编辑策略"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                      以此模板新建
                                    </button>
                                  </div>

                                  {/* Seeds hook Checkbox & Analyzer toggle */}
                                  <div className="flex items-center gap-3">
                                    <button
                                      onClick={() => onToggleSeed(strat.id, 'strategy', strat.tagline, brand.name, strat.coreFocus)}
                                      className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                                        isSeed
                                          ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                                          : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                                      }`}
                                    >
                                      <input
                                        type="checkbox"
                                        checked={isSeed}
                                        readOnly
                                        className="w-3.5 h-3.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 pointer-events-none"
                                      />
                                      灵感种子
                                    </button>
                                    
                                    <button
                                      onClick={() => handleLoadToAnalyzer(strat, 'strategy')}
                                      className="bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                                    >
                                      <BrainCircuit className="w-3.5 h-3.5" />
                                      AI 联想
                                    </button>
                                  </div>
                                </div>

                                {/* Content representation */}
                                <div className="mt-4 space-y-3">
                                  <div className="text-sm font-bold text-gray-800">{strat.tagline}</div>
                                  
                                  <div className="flex flex-wrap gap-1.5 mt-2">
                                    {strat.keywords.map((word, i) => (
                                      <span key={i} className="text-[10px] font-semibold bg-gray-50 border border-gray-200 text-gray-600 px-2 py-0.5 rounded">
                                        {word}
                                      </span>
                                    ))}
                                  </div>

                                  <div className="text-xs text-slate-500 leading-relaxed font-normal">
                                    <span className="font-bold text-gray-700">🎯 受众群体：</span>{strat.targetAudience}
                                  </div>

                                  <div className="text-xs bg-slate-50/60 border border-slate-100 p-3.5 rounded-xl text-slate-600 leading-relaxed font-normal whitespace-pre-wrap font-sans">
                                    <span className="font-bold text-gray-700 block mb-1">🎯 策略重点：</span>
                                    {strat.coreFocus}
                                  </div>

                                  {/* Extended fields for annual business report summaries */}
                                  {(strat.revenueInfo || strat.storeCountInfo || strat.keyProductsInfo) && (
                                    <div className="border-t border-slate-100 pt-3.5 mt-3">
                                      <span className="text-[10px] font-extrabold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                                        📊 {strat.year} 年度商业报告总结 (Business Report)
                                      </span>
                                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
                                        {strat.revenueInfo && (
                                          <div className="bg-slate-50/45 border border-slate-150 p-3 rounded-xl">
                                            <span className="text-[10px] font-extrabold text-slate-400 block mb-1">💰 营收及利润概况</span>
                                            <p className="text-[11px] text-slate-600 leading-relaxed font-normal mt-1">{strat.revenueInfo}</p>
                                          </div>
                                        )}
                                        {strat.storeCountInfo && (
                                          <div className="bg-slate-50/45 border border-slate-150 p-3 rounded-xl">
                                            <span className="text-[10px] font-extrabold text-slate-400 block mb-1">🏪 门店及规模变动</span>
                                            <p className="text-[11px] text-slate-600 leading-relaxed font-normal mt-1">{strat.storeCountInfo}</p>
                                          </div>
                                        )}
                                        {strat.keyProductsInfo && (
                                          <div className="bg-slate-50/45 border border-slate-150 p-3 rounded-xl">
                                            <span className="text-[10px] font-extrabold text-slate-400 block mb-1">🎁 核心爆款与价格带</span>
                                            <p className="text-[11px] text-slate-600 leading-relaxed font-normal mt-1">{strat.keyProductsInfo}</p>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div className="py-12 bg-white rounded-2xl border text-center text-slate-400 italic text-xs">
                        该年度目前暂无该品牌年度策略数据
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={handleCreateBlankStrategy}
                      className="w-full py-3.5 border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/30 hover:bg-slate-55/60 text-slate-400 hover:text-indigo-600 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold transition-all cursor-pointer hover:shadow-sm"
                    >
                      <PlusCircle className="w-4 h-4 text-slate-400 group-hover:scale-110 transition-transform" />
                      ➕ 添加全新年度战略策略板块
                    </button>
                  </div>
                );
              })()
            )}

            {/* 2. MARKETING ACTIONS FEED */}
            {activeTab === 'action' && (
              (() => {
                const visibleActions = actions.filter((a) => {
                  if (selectedYear === 'all') return true;
                  const yearStr = a.date.split('-')[0];
                  return yearStr === String(selectedYear);
                });
                return (
                  <div className="space-y-4">
                    {visibleActions.length > 0 ? (
                      visibleActions.map((act) => {
                        const isSeed = selectedSeedIds.includes(act.id);
                        return (
                          <div
                            key={act.id}
                            className={`relative bg-white border p-5 rounded-2xl shadow-sm transition-all flex flex-col ${cardSelectedBorder(act.id)}`}
                          >
                            {editingActionId === act.id ? (
                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  if (editActionData) {
                                    onUpdateAction(editActionData);
                                  }
                                  setEditingActionId(null);
                                  setEditActionData(null);
                                }}
                                className="space-y-4"
                              >
                                <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                                  <span className="text-xs font-extrabold text-indigo-700 flex items-center gap-1">
                                    <Edit2 className="w-3.5 h-3.5" /> 编辑营销战役动作
                                  </span>
                                  <div className="flex gap-2">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        onDeleteAction(act.id);
                                        setEditingActionId(null);
                                        setEditActionData(null);
                                      }}
                                      className="text-xs bg-rose-50 hover:bg-rose-100 text-rose-600 px-2.5 py-1 rounded font-semibold flex items-center gap-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      删除此动作
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingActionId(null);
                                        setEditActionData(null);
                                      }}
                                      className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-500 px-2.5 py-1 rounded font-semibold cursor-pointer"
                                    >
                                      取消
                                    </button>
                                    <button
                                      type="submit"
                                      className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded font-bold flex items-center gap-1 cursor-pointer shadow-sm"
                                    >
                                      <Save className="w-3.5 h-3.5" />
                                      保存
                                    </button>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">活动日期 (YYYY-MM-DD)</label>
                                    <input
                                      type="date"
                                      value={editActionData?.date || ''}
                                      onChange={(e) => setEditActionData(p => p ? { ...p, date: e.target.value } : null)}
                                      required
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">主要关联季度 (Quarter)</label>
                                    <select
                                      value={editActionData?.quarter || ''}
                                      onChange={(e) => setEditActionData(p => p ? { ...p, quarter: (e.target.value as any) || undefined } : null)}
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    >
                                      <option value="">（关联季度）</option>
                                      <option value="Q1">Q1 第一季度</option>
                                      <option value="Q2">Q2 第二季度</option>
                                      <option value="Q3">Q3 第三季度</option>
                                      <option value="Q4">Q4 第四季度</option>
                                    </select>
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">战役核心分类 (Type)</label>
                                    <input
                                      type="text"
                                      value={editActionData?.type || ''}
                                      onChange={(e) => setEditActionData(p => p ? { ...p, type: e.target.value } : null)}
                                      required
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 mb-1">营销活动战役口径名称 (Title)</label>
                                  <input
                                    type="text"
                                    value={editActionData?.title || ''}
                                    onChange={(e) => setEditActionData(p => p ? { ...p, title: e.target.value } : null)}
                                    required
                                    className="w-full text-xs font-bold border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                  />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">核心投放及宣发渠道 (逗号英文分隔)</label>
                                    <input
                                      type="text"
                                      value={editActionData?.channels.join(', ') || ''}
                                      onChange={(e) => setEditActionData(p => p ? { ...p, channels: e.target.value.split(',').map(s => s.trim()).filter(Boolean) } : null)}
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">战役结果概括与成效 (Results)</label>
                                    <input
                                      type="text"
                                      value={editActionData?.results || ''}
                                      onChange={(e) => setEditActionData(p => p ? { ...p, results: e.target.value } : null)}
                                      placeholder="写下成效数字或定性结论..."
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 mb-1">具体玩法、战役链路和创意详情 (Description)</label>
                                  <textarea
                                    value={editActionData?.description || ''}
                                    onChange={(e) => setEditActionData(p => p ? { ...p, description: e.target.value } : null)}
                                    required
                                    rows={3}
                                    className="w-full text-xs border border-gray-200 rounded p-2 bg-white text-slate-800 font-normal resize-none"
                                  ></textarea>
                                </div>

                                <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl space-y-3">
                                  <span className="text-[10px] font-extrabold text-slate-500 tracking-wide block">
                                    📊 季度报告大盘洞察与本季新品详情（选填）
                                  </span>
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 px-1">
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-400 mb-1">本季度盘点与策略特征</label>
                                      <textarea
                                        value={editActionData?.quarterlySummary || ''}
                                        onChange={(e) => setEditActionData(p => p ? { ...p, quarterlySummary: e.target.value } : null)}
                                        rows={2}
                                        placeholder="例如：本季主打复古跑鞋风格..."
                                        className="w-full text-[10px] border border-gray-100 rounded p-1.5 bg-white text-slate-700 font-normal resize-none"
                                      ></textarea>
                                    </div>
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-400 mb-1">本季重磅新品及商品信息</label>
                                      <textarea
                                        value={editActionData?.newProducts || ''}
                                        onChange={(e) => setEditActionData(p => p ? { ...p, newProducts: e.target.value } : null)}
                                        rows={2}
                                        placeholder="例如：透气网面升级技术款新品..."
                                        className="w-full text-[10px] border border-gray-100 rounded p-1.5 bg-white text-slate-700 font-normal resize-none"
                                      ></textarea>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            ) : (
                              <>
                                <div className="flex items-start justify-between gap-3 pb-3 border-b border-gray-100/60">
                                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-gray-500">
                                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                                    <span className="font-bold">{act.date}</span>
                                    {act.quarter && (
                                      <>
                                        <span className="w-1.5 h-1.5 bg-gray-300 rounded-full"></span>
                                        <span className="font-extrabold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200/40 text-[10px] tracking-wide uppercase">{act.quarter} 季度</span>
                                      </>
                                    )}
                                    <span className="w-1.5 h-1.5 bg-gray-300 rounded-full"></span>
                                    <span className="font-semibold text-indigo-600">{act.type}</span>

                                    <button
                                      onClick={() => {
                                        setEditingActionId(act.id);
                                        setEditActionData({ ...act });
                                      }}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50"
                                    >
                                      <Edit2 className="w-3.5 h-3.5" />
                                      编辑
                                    </button>

                                    <button
                                      onClick={() => handleCloneAction(act)}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50"
                                      title="以此案模板复制一个一模一样待编辑的战役活动数据"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                      以此模板新建
                                    </button>
                                  </div>

                                  <div className="flex items-center gap-3">
                                    <button
                                      onClick={() => onToggleSeed(act.id, 'action', act.title, brand.name, act.description)}
                                      className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                                        isSeed
                                          ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                                          : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                                      }`}
                                    >
                                      <input
                                        type="checkbox"
                                        checked={isSeed}
                                        readOnly
                                        className="w-3.5 h-3.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 pointer-events-none"
                                      />
                                      灵感种子
                                    </button>
                                    
                                    <button
                                      onClick={() => handleLoadToAnalyzer(act, 'action')}
                                      className="bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                                    >
                                      <BrainCircuit className="w-3.5 h-3.5" />
                                      AI 联想
                                    </button>
                                  </div>
                                </div>

                                <div className="mt-4 space-y-3">
                                  <div className="text-sm font-bold text-gray-800">{act.title}</div>

                                  <div className="text-xs text-slate-500 font-semibold flex items-center gap-1">
                                    <Share2 className="w-3 h-3 text-slate-400" />
                                    渠道：{act.channels.join(" | ")}
                                  </div>

                                  <div className="text-xs text-slate-600 leading-relaxed font-normal whitespace-pre-wrap font-sans">
                                    <span className="font-bold text-gray-700 block mb-1">📋 战役及活动详情：</span>
                                    {act.description}
                                  </div>

                                  {act.results && (
                                    <div className="text-xs bg-emerald-50/40 border border-emerald-105 p-3 rounded-xl text-emerald-800 leading-relaxed font-normal">
                                      <span className="font-bold text-emerald-950 block mb-1">📈 营销结果及成效研判：</span>
                                      {act.results}
                                    </div>
                                  )}

                                  {/* Extended fields for quarterly marketing products & summaries */}
                                  {(act.quarterlySummary || act.newProducts) && (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-3.5 border-t border-slate-100 mt-3">
                                      {act.quarterlySummary && (
                                        <div className="bg-amber-50/20 border border-amber-100/50 p-3.5 rounded-xl text-amber-900">
                                          <span className="font-extrabold text-amber-950 text-[10px] block mb-1.5 uppercase tracking-wider">📊 {act.quarter || '本季度'} 季度盘点与策略特征</span>
                                          <p className="text-[11px] leading-relaxed font-normal">{act.quarterlySummary}</p>
                                        </div>
                                      )}
                                      {act.newProducts && (
                                        <div className="bg-lime-50/20 border border-lime-100/40 p-3.5 rounded-xl text-lime-900">
                                          <span className="font-extrabold text-lime-950 text-[10px] block mb-1.5 uppercase tracking-wider">🎁 本季重磅新品及商品信息</span>
                                          <p className="text-[11px] leading-relaxed font-normal">{act.newProducts}</p>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div className="py-12 bg-white rounded-2xl border text-center text-slate-400 italic text-xs">
                        该年度目前暂无此品牌特色营销活动数据
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={handleCreateBlankAction}
                      className="w-full py-3.5 border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/30 hover:bg-slate-55/60 text-slate-400 hover:text-indigo-600 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold transition-all cursor-pointer hover:shadow-sm"
                    >
                      <PlusCircle className="w-4 h-4 text-slate-400 group-hover:scale-110 transition-transform" />
                      ➕ 添加全新品牌营销活动战役板块
                    </button>
                  </div>
                );
              })()
            )}

            {/* 3. NEW MEDIA OPERATIONS FEED */}
            {activeTab === 'operation' && (
              (() => {
                const visibleOps = operations.filter((o) => {
                  if (selectedYear === 'all') return true;
                  const yearStr = o.postDate.split('-')[0];
                  return yearStr === String(selectedYear);
                });
                return (
                  <div className="space-y-4">
                    {visibleOps.length > 0 ? (
                      visibleOps.map((op) => {
                        const isSeed = selectedSeedIds.includes(op.id);
                        const platformBadge = 
                          op.platform === 'Red' ? { bColor: 'bg-red-50 text-red-600 border-red-100', text: '小红书' } :
                          op.platform === 'Weixin' ? { bColor: 'bg-emerald-50 text-emerald-700 border-emerald-100', text: '微信官号' } :
                          op.platform === 'Weibo' ? { bColor: 'bg-amber-50 text-amber-700 border-amber-100', text: '微博' } :
                          { bColor: 'bg-gray-50 text-gray-600 border-gray-150', text: op.platform };

                        return (
                          <div
                            key={op.id}
                            className={`relative bg-white border p-5 rounded-2xl shadow-sm transition-all flex flex-col ${cardSelectedBorder(op.id)}`}
                          >
                            {editingOperationId === op.id ? (
                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  if (editOperationData) {
                                    onUpdateOperation(editOperationData);
                                  }
                                  setEditingOperationId(null);
                                  setEditOperationData(null);
                                }}
                                className="space-y-4"
                              >
                                <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                                  <span className="text-xs font-extrabold text-indigo-700 flex items-center gap-1">
                                    <Edit2 className="w-3.5 h-3.5" /> 编辑社交媒体推文及汇总主干
                                  </span>
                                  <div className="flex gap-2">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        onDeleteOperation(op.id);
                                        setEditingOperationId(null);
                                        setEditOperationData(null);
                                      }}
                                      className="text-xs bg-rose-50 hover:bg-rose-100 text-rose-600 px-2.5 py-1 rounded font-semibold flex items-center gap-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      删除此推文
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingOperationId(null);
                                        setEditOperationData(null);
                                      }}
                                      className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-500 px-2.5 py-1 rounded font-semibold cursor-pointer"
                                    >
                                      取消
                                    </button>
                                    <button
                                      type="submit"
                                      className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded font-bold flex items-center gap-1 cursor-pointer shadow-sm"
                                    >
                                      <Save className="w-3.5 h-3.5" />
                                      保存
                                    </button>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">推广平台</label>
                                    <select
                                      value={editOperationData?.platform || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, platform: e.target.value as any } : null)}
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800 font-medium"
                                    >
                                      <option value="Red">小红书</option>
                                      <option value="Weixin">微信官号</option>
                                      <option value="Weibo">微博</option>
                                      <option value="Douyin">抖音</option>
                                      <option value="Other">其他媒体渠道</option>
                                    </select>
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">官方媒体账号名/博主</label>
                                    <input
                                      type="text"
                                      value={editOperationData?.accountName || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, accountName: e.target.value } : null)}
                                      required
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">推文发布日期</label>
                                    <input
                                      type="date"
                                      value={editOperationData?.postDate || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, postDate: e.target.value } : null)}
                                      required
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">年度关联季度</label>
                                    <select
                                      value={editOperationData?.quarter || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, quarter: (e.target.value as any) || undefined } : null)}
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    >
                                      <option value="">（未选定）</option>
                                      <option value="Q1">Q1 季度</option>
                                      <option value="Q2">Q2 季度</option>
                                      <option value="Q3">Q3 季度</option>
                                      <option value="Q4">Q4 季度</option>
                                    </select>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                  <div className="md:col-span-2">
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">推文核心主题 / 季度智能大盘盘点名称 (Title)</label>
                                    <input
                                      type="text"
                                      value={editOperationData?.postTitle || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, postTitle: e.target.value } : null)}
                                      required
                                      className="w-full text-xs font-bold border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 mb-1">互动统计成效 (Interaction)</label>
                                    <input
                                      type="text"
                                      value={editOperationData?.interactionCount || ''}
                                      onChange={(e) => setEditOperationData(p => p ? { ...p, interactionCount: e.target.value } : null)}
                                      placeholder="点赞、转发及阅读数据等..."
                                      className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                    />
                                  </div>
                                </div>

                                <div className="flex items-center gap-1.5 py-1">
                                  <input
                                    type="checkbox"
                                    id={`isSummary-${op.id}`}
                                    checked={editOperationData?.isQuarterlySummary || false}
                                    onChange={(e) => {
                                      const checked = e.target.checked;
                                      setEditOperationData(p => {
                                        if (!p) return null;
                                        const base = { ...p, isQuarterlySummary: checked } as any;
                                        if (checked && !base.platformsIntel) {
                                          base.platformsIntel = [
                                            { platformName: 'Douyin', postCount: '0 篇', mainTheme: '特色品推文案', overallStyle: '精致山野深色调', keyMessages: '强调防护性' },
                                            { platformName: 'Red', postCount: '0 篇', mainTheme: '爆款户外穿搭话题', overallStyle: '治愈胶片感色调', keyMessages: '生活方式轻装出行' },
                                            { platformName: 'Weixin', postCount: '0 篇', mainTheme: '专业面料技术评测', overallStyle: '科研写实硬朗感', keyMessages: '材料科技大赏' }
                                          ];
                                        }
                                        return base;
                                      });
                                    }}
                                    className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                  />
                                  <label htmlFor={`isSummary-${op.id}`} className="text-xs font-extrabold text-indigo-950 cursor-pointer">
                                    💡 确认将此卡片设定为「多平台渠道季度智能洞察报告模板汇总」样式
                                  </label>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 mb-1">推文帖子正文脚本 / 季度主轴传播心理与传播规律盘点(Content)</label>
                                  <textarea
                                    value={editOperationData?.postContent || ''}
                                    onChange={(e) => setEditOperationData(p => p ? { ...p, postContent: e.target.value } : null)}
                                    required
                                    rows={4}
                                    className="w-full text-xs font-mono border border-gray-200 rounded p-2 bg-white text-slate-800 resize-none leading-relaxed"
                                  ></textarea>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 mb-1">视觉调性调配 / 画面及色彩设计主张 (VisualStyle)</label>
                                  <input
                                    type="text"
                                    value={editOperationData?.visualStyle || ''}
                                    onChange={(e) => setEditOperationData(p => p ? { ...p, visualStyle: e.target.value } : null)}
                                    placeholder="例如：冷深绿搭配高饱和暖黄色，凸显山系专业感"
                                    className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 bg-white text-slate-800"
                                  />
                                </div>

                                {editOperationData?.isQuarterlySummary && editOperationData?.platformsIntel && (
                                  <div className="bg-indigo-50/40 border border-indigo-150 p-3.5 rounded-xl space-y-3">
                                    <span className="text-[10px] font-extrabold text-indigo-950 uppercase tracking-wider block">
                                      💻 季度平台自营渠道三合一数据与洞察卡片统计：
                                    </span>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                      {editOperationData.platformsIntel.map((intel, idx) => {
                                        const platCN = intel.platformName === 'Douyin' ? '抖音' : intel.platformName === 'Red' ? '小红书' : '微信官号';
                                        return (
                                          <div key={idx} className="bg-white p-2.5 border border-indigo-100 rounded-lg space-y-2">
                                            <div className="flex items-center justify-between border-b border-gray-100 pb-1 mb-1 text-[10px] font-extrabold">
                                              <span>{platCN} 平台指标</span>
                                              <input
                                                type="text"
                                                value={intel.postCount}
                                                onChange={(e) => {
                                                  const val = e.target.value;
                                                  setEditOperationData(p => {
                                                    if (!p || !p.platformsIntel) return null;
                                                    const copy = [...p.platformsIntel];
                                                    copy[idx] = { ...copy[idx], postCount: val };
                                                    return { ...p, platformsIntel: copy };
                                                  });
                                                }}
                                                className="w-14 text-right border-none p-0 text-[10px] font-mono font-bold focus:ring-0 text-indigo-600 bg-transparent"
                                                placeholder="发帖篇数"
                                              />
                                            </div>
                                            <div className="space-y-1 text-[9px]">
                                              <div>
                                                <span className="text-slate-400 font-bold">主旨: </span>
                                                <input
                                                  type="text"
                                                  value={intel.mainTheme}
                                                  onChange={(e) => {
                                                    const val = e.target.value;
                                                    setEditOperationData(p => {
                                                      if (!p || !p.platformsIntel) return null;
                                                      const copy = [...p.platformsIntel];
                                                      copy[idx] = { ...copy[idx], mainTheme: val };
                                                      return { ...p, platformsIntel: copy };
                                                    });
                                                  }}
                                                  className="w-full border-none p-0 text-[10px] text-slate-800 focus:ring-0 bg-transparent"
                                                />
                                              </div>
                                              <div>
                                                <span className="text-slate-400 font-bold">调性: </span>
                                                <input
                                                  type="text"
                                                  value={intel.overallStyle}
                                                  onChange={(e) => {
                                                    const val = e.target.value;
                                                    setEditOperationData(p => {
                                                      if (!p || !p.platformsIntel) return null;
                                                      const copy = [...p.platformsIntel];
                                                      copy[idx] = { ...copy[idx], overallStyle: val };
                                                      return { ...p, platformsIntel: copy };
                                                    });
                                                  }}
                                                  className="w-full border-none p-0 text-[10px] text-slate-800 focus:ring-0 bg-transparent"
                                                />
                                              </div>
                                              <div>
                                                <span className="text-slate-400 font-bold">要务: </span>
                                                <input
                                                  type="text"
                                                  value={intel.keyMessages}
                                                  onChange={(e) => {
                                                    const val = e.target.value;
                                                    setEditOperationData(p => {
                                                      if (!p || !p.platformsIntel) return null;
                                                      const copy = [...p.platformsIntel];
                                                      copy[idx] = { ...copy[idx], keyMessages: val };
                                                      return { ...p, platformsIntel: copy };
                                                    });
                                                  }}
                                                  className="w-full border-none p-0 text-[10px] text-slate-800 focus:ring-0 bg-transparent"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </div>
                                )}
                              </form>
                            ) : (
                              <>
                                <div className="flex items-start justify-between gap-3 pb-3 border-b border-gray-100/60 font-medium">
                                  <div className="flex flex-wrap items-center gap-1.5 text-xs">
                                    {op.isQuarterlySummary ? (
                                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded border bg-indigo-50 text-indigo-700 border-indigo-150">
                                        智能汇总
                                      </span>
                                    ) : (
                                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded border ${platformBadge.bColor}`}>
                                        {platformBadge.text}
                                      </span>
                                    )}
                                    <span className="text-[11px] font-semibold text-gray-400">@{op.accountName}</span>
                                    {op.quarter && (
                                      <span className="font-extrabold text-amber-600 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200/40 text-[9px] tracking-wider uppercase">
                                        {op.quarter} 季度
                                      </span>
                                    )}
                                    <span className="text-[10px] text-gray-400 font-mono">({op.postDate})</span>

                                    <button
                                      onClick={() => {
                                        setEditingOperationId(op.id);
                                        setEditOperationData({ ...op });
                                      }}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50 ml-1"
                                    >
                                      <Edit2 className="w-3.5 h-3.5" />
                                      编辑
                                    </button>

                                    <button
                                      onClick={() => handleCloneOperation(op)}
                                      className="text-slate-400 hover:text-indigo-600 p-1 px-1.5 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-0.5 border border-transparent hover:border-indigo-100 rounded hover:bg-indigo-50/50"
                                      title="以此案模板复制一个完全相同的推文发帖数据模型"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                      以此模板新建
                                    </button>
                                  </div>

                                  <div className="flex items-center gap-3">
                                    <button
                                      onClick={() => onToggleSeed(op.id, 'operation', op.postTitle, brand.name, op.postContent)}
                                      className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                                        isSeed
                                          ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                                          : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                                      }`}
                                    >
                                      <input
                                        type="checkbox"
                                        checked={isSeed}
                                        readOnly
                                        className="w-3.5 h-3.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 pointer-events-none"
                                      />
                                      灵感种子
                                    </button>
                                    
                                    <button
                                      onClick={() => handleLoadToAnalyzer(op, 'operation')}
                                      className="bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                                    >
                                      <BrainCircuit className="w-3.5 h-3.5" />
                                      AI 联想
                                    </button>
                                  </div>
                                </div>

                                <div className="mt-4 space-y-3.5">
                                  <div className="text-sm font-bold text-gray-800 leading-snug">
                                    {op.isQuarterlySummary ? (
                                      <span className="flex items-center gap-1.5 text-indigo-700 text-sm font-extrabold">
                                        📊 {op.postTitle}
                                      </span>
                                    ) : (
                                      op.postTitle
                                    )}
                                  </div>

                                  {op.visualStyle && (
                                    <div className="text-[11px] text-slate-500 leading-relaxed font-medium bg-slate-50 border border-slate-100/60 px-3 py-2 rounded-lg">
                                      <span className="font-bold text-slate-700">🎨 {op.isQuarterlySummary ? "季度视觉设计趋势大汇算：" : "视觉海报/色度调配："}</span>
                                      {op.visualStyle}
                                    </div>
                                  )}

                                  <div className={`text-xs text-slate-600 leading-relaxed font-sans p-4 rounded-xl border border-dashed border-slate-200/50 block ${op.isQuarterlySummary ? 'bg-indigo-50/10 font-normal leading-relaxed' : 'bg-slate-100/40 font-mono select-all'}`}>
                                    {op.isQuarterlySummary && <strong className="font-extrabold text-indigo-950 block mb-1">📋 季度全媒体运营主轴与社交心理：</strong>}
                                    {op.postContent}
                                  </div>

                                  {/* Render the 3 social media platforms grid if isQuarterlySummary is true */}
                                  {op.isQuarterlySummary && op.platformsIntel && (
                                    <div className="space-y-3.5 pt-2">
                                      <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">
                                        💻 抖音/小红书/微信公众号：官方自营三部曲季度智能分类盘底
                                      </span>
                                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                                        {op.platformsIntel.map((intel, idx) => {
                                          let platformCN = "其他社交";
                                          let platformColor = "border-gray-200 bg-gray-50/50 text-gray-900";
                                          if (intel.platformName === 'Douyin') {
                                            platformCN = "抖音短视频";
                                            platformColor = "border-pink-100 bg-pink-50/20 text-pink-950 focus:ring-pink-500";
                                          } else if (intel.platformName === 'Red') {
                                            platformCN = "小红书 (Red)";
                                            platformColor = "border-red-100 bg-red-50/20 text-red-950 focus:ring-red-500";
                                          } else if (intel.platformName === 'Weixin') {
                                            platformCN = "微信公众号";
                                            platformColor = "border-emerald-100 bg-emerald-50/20 text-emerald-950 focus:ring-emerald-500";
                                          }

                                          return (
                                            <div key={idx} className={`border rounded-xl p-3.5 flex flex-col justify-between space-y-3.5 transition-all hover:shadow-sm ${platformColor}`}>
                                              <div>
                                                <div className="flex items-center justify-between border-b border-current/10 pb-2 mb-2 font-extrabold text-[11px]">
                                                  <span>{platformCN}</span>
                                                  <span className="bg-white/80 px-2 py-0.5 rounded-full font-mono text-[9px] text-slate-700 tracking-wider font-extrabold shadow-sm">
                                                    {intel.postCount}
                                                  </span>
                                                </div>
                                                <div className="space-y-1.5 text-[11px] leading-relaxed font-medium">
                                                  <p className="font-normal">
                                                    <strong className="font-extrabold">内容主旨: </strong>{intel.mainTheme}
                                                  </p>
                                                  <p className="font-normal">
                                                    <strong className="font-extrabold">视觉调性: </strong>{intel.overallStyle}
                                                  </p>
                                                </div>
                                              </div>
                                              <div className="text-[10px] leading-relaxed pt-2 border-t border-current/10 text-slate-500 font-medium font-normal">
                                                <strong className="font-extrabold text-slate-800">💡 传播要务: </strong>{intel.keyMessages}
                                              </div>
                                            </div>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  )}

                                  <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1 mt-1">
                                    <Clock className="w-3 h-3 text-slate-300" />
                                    {op.isQuarterlySummary ? "季度全网总计数据大盘活跃指数：" : "互动成效统计数据："}
                                    {op.interactionCount}
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div className="py-12 bg-white rounded-2xl border text-center text-gray-400 italic text-xs">
                        该年度目前暂无此自营社媒推文与汇总数据
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={handleCreateBlankOperation}
                      className="w-full py-3.5 border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/30 hover:bg-slate-55/60 text-slate-400 hover:text-indigo-600 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold transition-all cursor-pointer hover:shadow-sm"
                    >
                      <PlusCircle className="w-4 h-4 text-slate-400 group-hover:scale-110 transition-transform" />
                      ➕ 添加全新推文发帖及自营分析汇总
                    </button>
                  </div>
                );
              })()
            )}

            {/* 4. CUSTOM SECTIONS FEED */}
            {activeTab === 'custom' && (
              (() => {
                const sections = brand.customSections || [];
                return sections.length > 0 ? (
                  sections.map((sec) => (
                    <div
                      key={sec.id}
                      className="relative bg-white border border-slate-150 p-5 rounded-2xl shadow-sm transition-all flex flex-col"
                    >
                      {editingSectionId === sec.id ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            const titleInput = (e.currentTarget.elements.namedItem('editTitle') as HTMLInputElement).value;
                            const descInput = (e.currentTarget.elements.namedItem('editDesc') as HTMLTextAreaElement).value;
                            handleSaveEditedCustomSection(sec.id, titleInput, descInput);
                          }}
                          className="space-y-3"
                        >
                          <div>
                            <label className="block text-[10px] font-bold text-gray-500 mb-1">编辑类目名称</label>
                            <input
                              type="text"
                              name="editTitle"
                              defaultValue={sec.title}
                              required
                              className="w-full text-xs border border-gray-200 rounded px-2.5 py-1.5 text-slate-800"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-gray-500 mb-1">编辑细分内容记录</label>
                            <textarea
                              name="editDesc"
                              defaultValue={sec.content}
                              required
                              rows={5}
                              className="w-full text-xs border border-gray-200 rounded p-2 text-slate-800 resize-none"
                            ></textarea>
                          </div>
                          <div className="flex justify-end gap-2 text-xs">
                            <button
                              type="button"
                              onClick={() => setEditingSectionId(null)}
                              className="px-2.5 py-1 border border-slate-200 rounded text-gray-500 hover:bg-slate-50 font-semibold"
                            >
                              取消
                            </button>
                            <button
                              type="submit"
                              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-bold"
                            >
                              保存修改
                            </button>
                          </div>
                        </form>
                      ) : (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                            <div className="text-xs font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                              补充维度：{sec.title}
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setEditingSectionId(sec.id)}
                                className="text-[11px] font-semibold text-slate-500 hover:text-indigo-600 cursor-pointer"
                              >
                                编辑内容
                              </button>
                              <span className="text-gray-200">|</span>
                              <button
                                onClick={() => handleDeleteCustomSection(sec.id)}
                                className="text-[11px] font-semibold text-rose-500 hover:text-rose-700 cursor-pointer"
                              >
                                彻底删除
                              </button>
                            </div>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed font-normal whitespace-pre-wrap pt-1 font-sans">{sec.content}</p>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="py-12 bg-white rounded-2xl border border-dashed text-center text-slate-400 text-xs">
                    <p className="font-bold text-slate-500">此品牌尚未定义专属补充类目</p>
                    <p className="text-[10px] text-slate-400 font-normal mt-1 max-w-[340px] mx-auto leading-relaxed">
                      请点击右上角【写笔记收录新内容】按钮，并在分类中选择“专有补充类目”，即可手动创建如“上下游供应链优势”等自定义维度来精研品牌。
                    </p>
                  </div>
                );
              })()
            )}
          </div>
        </div>
      </div>

      {/* AI Association Intelligence Dock (Right col - span 5) */}
      <div className="lg:col-span-5 space-y-5" id="ai-association-intelligence-dock">
        <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl shadow-lg p-5 min-h-[580px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3.5 mb-4">
              <span className="text-xs font-extrabold tracking-wider text-slate-400 flex items-center gap-2">
                <BrainCircuit className="w-4 h-4 text-indigo-400" />
                AI 知识联想器 (Active Analyzer)
              </span>
              
              {analyzingItem && (
                <button
                  onClick={() => {
                    setAnalyzingItem(null);
                    setFocusItem(null, null);
                    setAiSuggestions([]);
                  }}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  清除选择
                </button>
              )}
            </div>

            {analyzingItem ? (
              <div className="space-y-4" id="ai-analyzer-active-bay">
                {/* Active loaded element summary */}
                <div className="p-4 bg-slate-800/60 border border-slate-700/50 rounded-xl relative overflow-hidden">
                  <span className="absolute top-2 right-2.5 text-[9px] font-extrabold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                    {analyzingItem.itemType === 'strategy' ? '策略' : analyzingItem.itemType === 'action' ? '玩法' : '推文'}
                  </span>
                  <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">{brand.name}</div>
                  <h3 className="text-xs font-bold text-gray-100 mt-1 line-clamp-2">
                    {analyzingItem.title || analyzingItem.postTitle || analyzingItem.tagline || '未命名'}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-normal mt-2 line-clamp-3">
                    {analyzingItem.description || analyzingItem.postContent || analyzingItem.coreFocus}
                  </p>
                </div>

                {/* Match button trigger */}
                <button
                  onClick={handleRunAiAssociation}
                  disabled={isAiLoading}
                  className="w-full flex items-center justify-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white font-bold py-2.5 rounded-xl shadow-md transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-indigo-200" />
                  {isAiLoading ? 'AI 脑洞雷达扫寻中...' : '💡 启动跨品牌 AI 脑洞深度联想'}
                </button>

                {aiError && (
                  <p className="text-[11px] text-red-400 mt-1">联想匹配受限，请确认 Secrets API Key。系统目前启用预置语义模型提供高契合分析。</p>
                )}

                {/* List of fetched suggestions */}
                <div className="space-y-3.5 pt-3 overflow-y-auto max-h-[380px]" id="ai-suggestions-grid">
                  {aiSuggestions.length > 0 ? (
                    aiSuggestions.map((sugg, i) => (
                      <div
                        key={i}
                        className="p-3.5 bg-slate-950/60 border border-indigo-950/40 rounded-xl space-y-2.5 transition-all hover:border-indigo-500/30 animate-in fade-in zoom-in-95 duration-150"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-bold uppercase text-indigo-400 tracking-wider">
                            {sugg.targetBrandName}
                          </span>
                          <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                            {sugg.relationType === 'similar_tactic' ? '同类玩法' :
                             sugg.relationType === 'part_of_strategy' ? '落地实践' :
                             sugg.relationType === 'inspired_by' ? '创意启发' :
                             sugg.relationType === 'co_branding' ? '联名跨界' : '跨界借鉴'}
                          </span>
                        </div>

                        <div className="text-[11px] font-semibold text-slate-200 line-clamp-1">{sugg.targetTitle}</div>
                        <p className="text-[10px] text-slate-400 leading-relaxed font-normal bg-slate-900/60 p-2.5 rounded border border-slate-800">
                          {sugg.description}
                        </p>

                        <button
                          onClick={() => handleSaveAssociation(sugg)}
                          className="w-full text-[10px] bg-slate-800 hover:bg-indigo-600 text-indigo-200 hover:text-white font-bold py-1 px-3 rounded-lg transition-colors cursor-pointer"
                        >
                          💾 保存此项关联至总知识星图
                        </button>
                      </div>
                    ))
                  ) : !isAiLoading ? (
                    <div className="text-center py-10 text-slate-500 text-[11px] font-semibold">
                      点击上方按钮，AI 将扫描知识库中其余所有品牌的长线动作，为您寻找极具视觉、玩法或商业启发性的 2-3 个关联暗轨。
                    </div>
                  ) : null}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center text-center py-20 text-slate-500 my-auto">
                <BookOpen className="w-10 h-10 mb-3 stroke-slate-700 stroke-[1.5]" />
                <p className="text-xs font-bold text-slate-400">雷达处于待机状态</p>
                <p className="text-[11px] text-slate-500 mt-1 max-w-[220px]">
                  请点击左侧任何年度策略、营销活动或社媒帖子卡片上的【🧠 AI 联想】按钮。
                </p>
              </div>
            )}
          </div>

          {/* Persistent connections counts indicator */}
          <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-3.5 text-center text-slate-400 text-[10px] mt-4" id="brand-linked-paths-counts">
            {focusItemId ? (
              <p className="font-semibold text-slate-300">
                本条目当前已具有 <span className="text-indigo-400 font-bold text-xs">{linkedRelationships.length}</span> 条由星图保存的长效跨界关联。
              </p>
            ) : (
              <p className="font-normal text-slate-400 leading-normal">
                这个模块将直接帮助您寻找知识深层连接！通过在多维度间架设 AI 创意的桥梁，让您不仅单打独斗，而是整合全部品牌的实战洞察。
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
