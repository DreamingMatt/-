import React, { useState, useMemo } from 'react';
import { Brand, AnnualStrategy, MarketingAction, NewMediaOperation, Relationship, RelationType } from '../types';
import { Zap, HelpCircle, Link2, Plus, Sparkles, AlertCircle, Eye } from 'lucide-react';

interface ConnectionMapProps {
  brands: Brand[];
  strategies: AnnualStrategy[];
  actions: MarketingAction[];
  operations: NewMediaOperation[];
  relationships: Relationship[];
  onSelectNode: (type: 'strategy' | 'action' | 'operation', id: string) => void;
  onAddCustomRelation: (source: { id: string; type: string; title: string; brand: string }, target: { id: string; type: string; title: string; brand: string }, relationType: RelationType, desc: string) => void;
}

export default function ConnectionMap({
  brands,
  strategies,
  actions,
  operations,
  relationships,
  onSelectNode,
  onAddCustomRelation
}: ConnectionMapProps) {
  const [filterType, setFilterType] = useState<RelationType | 'all'>('all');
  const [activeRelationId, setActiveRelationId] = useState<string | null>(null);
  
  // Custom Relation Builder state
  const [showAddModal, setShowAddModal] = useState(false);
  const [sourceNodeId, setSourceNodeId] = useState('');
  const [targetNodeId, setTargetNodeId] = useState('');
  const [customRelationType, setCustomRelationType] = useState<RelationType>('similar_tactic');
  const [customDesc, setCustomDesc] = useState('');

  // Combine actions, operations, strategies into a unified searchable list of "Nodes" for linking
  const allNodes = useMemo(() => {
    const list: Array<{ id: string; type: 'strategy' | 'action' | 'operation'; title: string; brandName: string; brandId: string; description: string }> = [];
    
    strategies.forEach(s => {
      const brand = brands.find(b => b.id === s.brandId);
      list.push({
        id: s.id,
        type: 'strategy',
        title: `年度：${s.tagline}`,
        brandName: brand?.name || '未知品牌',
        brandId: s.brandId,
        description: s.coreFocus
      });
    });

    actions.forEach(a => {
      const brand = brands.find(b => b.id === a.brandId);
      list.push({
        id: a.id,
        type: 'action',
        title: `活动：${a.title}`,
        brandName: brand?.name || '未知品牌',
        brandId: a.brandId,
        description: a.description
      });
    });

    operations.forEach(o => {
      const brand = brands.find(b => b.id === o.brandId);
      list.push({
        id: o.id,
        type: 'operation',
        title: `${o.platform === 'Red' ? '小红书' : o.platform === 'Weixin' ? '微信' : o.platform}：${o.postTitle}`,
        brandName: brand?.name || '未知品牌',
        brandId: o.brandId,
        description: o.postContent
      });
    });

    return list;
  }, [brands, strategies, actions, operations]);

  // Coordinates generator for SVG nodes mapping in high-contrast spaces
  const nodeLayouts = useMemo(() => {
    const layouts: Record<string, { x: number; y: number; color: string }> = {};
    const brandColors: Record<string, string> = {
      'brand-1': '#ef4444', // Red for Lululemon
      'brand-2': '#065f46', // Emerald for Manner
      'brand-3': '#b45309', // Amber for Patagonia
      'brand-4': '#84cc16'  // Lime for Nayuki
    };

    // Calculate circular or group layouts based on brand IDs to keep related items grouped
    brands.forEach((brand, bIndex) => {
      const brandNodes = allNodes.filter(n => n.brandId === brand.id);
      const brandAngle = (bIndex * 2 * Math.PI) / brands.length;
      const brandRadius = 150; // Radius from center to brand cluster center
      const centerX = 380 + brandRadius * Math.cos(brandAngle);
      const centerY = 240 + brandRadius * Math.sin(brandAngle);

      brandNodes.forEach((node, nIndex) => {
        const localAngle = (nIndex * 2 * Math.PI) / Math.max(brandNodes.length, 1);
        const nodeRadius = 55; // Minor radius inside the cluster
        layouts[node.id] = {
          x: Math.round(centerX + nodeRadius * Math.cos(localAngle)),
          y: Math.round(centerY + nodeRadius * Math.sin(localAngle)),
          color: brandColors[brand.id] || '#6b7280'
        };
      });
    });

    return layouts;
  }, [brands, allNodes]);

  // Filter relationship connections
  const filteredRelations = useMemo(() => {
    return relationships.filter(rel => filterType === 'all' || rel.relationType === filterType);
  }, [relationships, filterType]);

  // Get active selected relationship
  const activeRelation = useMemo(() => {
    return relationships.find(rel => rel.id === activeRelationId);
  }, [relationships, activeRelationId]);

  // Add custom manual relationship logic
  const handleCreateCustomRelation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceNodeId || !targetNodeId || sourceNodeId === targetNodeId || !customDesc) {
      alert("请完整选择不相同的两个项目并填写关联理由分析！");
      return;
    }

    const source = allNodes.find(n => n.id === sourceNodeId)!;
    const target = allNodes.find(n => n.id === targetNodeId)!;

    onAddCustomRelation(
      { id: source.id, type: source.type, title: source.title, brand: source.brandName },
      { id: target.id, type: target.type, title: target.title, brand: target.brandName },
      customRelationType,
      customDesc
    );

    // Reset Form
    setSourceNodeId('');
    setTargetNodeId('');
    setCustomDesc('');
    setShowAddModal(false);
  };

  const relationshipTypes: Record<RelationType, { label: string; color: string; bg: string; border: string }> = {
    similar_tactic: { label: '同类玩法', color: 'text-violet-600', bg: 'bg-violet-50', border: 'border-violet-300' },
    part_of_strategy: { label: '落地实践', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-300' },
    inspired_by: { label: '创意启发', color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-300' },
    co_branding: { label: '联名跨界', color: 'text-pink-600', bg: 'bg-pink-50', border: 'border-pink-300' },
    cross_industry_reference: { label: '跨界借鉴', color: 'text-teal-600', bg: 'bg-teal-50', border: 'border-teal-300' },
    custom: { label: '自定义关联', color: 'text-gray-600', bg: 'bg-gray-50', border: 'border-gray-300' }
  };

  return (
    <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden p-6">
      {/* Header operations */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-5 mb-5" id="mindmap-header">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <span className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Link2 className="w-5 h-5" />
            </span>
            全量创意关联星图
          </h2>
          <p className="text-xs text-gray-500 mt-1">
            横跨品牌、年度战役与新媒体帖子，直观还原每个创意点子、环保动作或国潮审美的跨界融合脉络
          </p>
        </div>

        {/* Filters and Add Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Filter Dropdown */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="text-xs border border-gray-200 rounded-lg px-3 py-1.5 bg-gray-50 font-medium text-gray-700 outline-none focus:border-indigo-500 transition-colors"
          >
            <option value="all">🔍 显示全部关联</option>
            <option value="similar_tactic">🌸 同类玩法/手法</option>
            <option value="part_of_strategy">📌 年度大策略落地</option>
            <option value="inspired_by">💡 创意启发</option>
            <option value="co_branding">🤝 联名跨界联动</option>
            <option value="cross_industry_reference">🪐 跨品类商业借鉴</option>
            <option value="custom">💼 手写科研关联</option>
          </select>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-3.5 py-1.5 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            手写新建联系
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="mindmap-content-grid">
        {/* SVG Visualization Canvas */}
        <div className="lg:col-span-2 bg-slate-50 border border-slate-100/80 rounded-xl relative overflow-hidden min-h-[460px] flex items-center justify-center">
          {/* Cluster labels backgrounds */}
          <div className="absolute top-2 left-3 bg-red-50/70 border border-red-100 text-[10px] font-medium text-red-700 px-2 py-1 rounded">Lululemon 热汗社区</div>
          <div className="absolute top-2 right-3 bg-emerald-50/70 border border-emerald-100 text-[10px] font-medium text-emerald-700 px-2 py-1 rounded">Manner 环保活力</div>
          <div className="absolute bottom-2 left-3 bg-amber-50/70 border border-amber-100 text-[10px] font-medium text-amber-700 px-2 py-1 rounded">Patagonia 循环修补</div>
          <div className="absolute bottom-2 right-3 bg-lime-50/70 border border-lime-100 text-[10px] font-medium text-lime-700 px-2 py-1 rounded">奈雪的茶 宋代风雅</div>

          <svg viewBox="0 0 760 480" className="w-full h-full max-h-[480px]">
            {/* SVG Grid backgrounds */}
            <defs>
              <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#e2e8f0" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" opacity="0.4" />

            {/* Bezier connectors representation */}
            {filteredRelations.map((rel) => {
              const start = nodeLayouts[rel.sourceId];
              const end = nodeLayouts[rel.targetId];

              if (!start || !end) return null;

              const isActive = rel.id === activeRelationId;
              const relStyle = relationshipTypes[rel.relationType];
              
              // Draw a clean animated curved line
              const midX = (start.x + end.x) / 2;
              const midY = (start.y + end.y) / 2 - 35; // Curve height offset
              const pathString = `M ${start.x} ${start.y} Q ${midX} ${midY} ${end.x} ${end.y}`;

              return (
                <g key={rel.id} className="cursor-pointer" onClick={() => setActiveRelationId(rel.id)}>
                  {/* Thick glowing background path on click/hover */}
                  <path
                    d={pathString}
                    fill="none"
                    stroke={isActive ? '#6366f1' : 'transparent'}
                    strokeWidth={16}
                    opacity={isActive ? 0.15 : 0.4}
                    className="hover:stroke-indigo-400 hover:opacity-10 transition-all duration-300"
                  />
                  {/* Main path line */}
                  <path
                    d={pathString}
                    fill="none"
                    stroke={isActive ? '#4f46e5' : '#94a3b8'}
                    strokeWidth={isActive ? 3 : 1.5}
                    strokeDasharray={rel.isAiGenerated ? "5,5" : "none"}
                    className="transition-all duration-300"
                  />
                  {/* Small trigger circle/dot in middle of path to select connection */}
                  <circle
                    cx={midX}
                    cy={midY}
                    r={isActive ? 7 : 4}
                    fill={isActive ? '#4f46e5' : '#64748b'}
                    className="hover:scale-150 transition-transform shadow"
                  />
                </g>
              );
            })}

            {/* Strategy, action, operation nodes */}
            {allNodes.map((node) => {
              const layout = nodeLayouts[node.id];
              if (!layout) return null;

              // Check if node is part of the currently active relationship
              const isSourceInActive = activeRelation?.sourceId === node.id;
              const isTargetInActive = activeRelation?.targetId === node.id;
              const isLinkedToActive = isSourceInActive || isTargetInActive;

              const isStrategy = node.type === 'strategy';
              const isAction = node.type === 'action';
              const isOperation = node.type === 'operation';

              return (
                <g
                  key={node.id}
                  className="cursor-pointer select-none"
                  transform={`translate(${layout.x}, ${layout.y})`}
                  onClick={() => onSelectNode(node.type, node.id)}
                >
                  {/* Glow circle for active connection node elements */}
                  {isLinkedToActive && (
                    <circle
                      r={24}
                      fill="none"
                      stroke="#4f46e5"
                      strokeWidth={2.5}
                      className="animate-pulse"
                    />
                  )}

                  {/* Colored core circle based on type and brand */}
                  <circle
                    r={isStrategy ? 16 : isAction ? 13 : 11}
                    fill={layout.color}
                    className="transition-all hover:scale-110 shadow-sm"
                  />

                  {/* Shape outline to indicate node item category */}
                  {isStrategy && (
                    <circle r={20} fill="none" stroke={layout.color} strokeWidth={1} strokeDasharray="3,3" opacity={0.6} />
                  )}

                  {/* Elegant micro text tags representing node acronym/label */}
                  <text
                    y={5}
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize={isStrategy ? '9px' : '8px'}
                    fontWeight="bold"
                    pointerEvents="none"
                  >
                    {isStrategy ? '策' : isAction ? '行' : '媒'}
                  </text>

                  {/* Responsive overlay tag showing brand and title */}
                  <g transform="translate(0, 26)" className="opacity-0 hover:opacity-100 transition-opacity duration-200 select-none">
                    <rect
                      x={-60}
                      y={-10}
                      width={120}
                      height={34}
                      fill="#1e293b"
                      rx={4}
                      className="shadow-md"
                    />
                    <text
                      y={2}
                      textAnchor="middle"
                      fill="#f8fafc"
                      fontSize="8px"
                      fontWeight="bold"
                    >
                      {node.brandName}
                    </text>
                    <text
                      y={14}
                      textAnchor="middle"
                      fill="#cbd5e1"
                      fontSize="7px"
                    >
                      {node.title.slice(0, 15)}...
                    </text>
                  </g>
                </g>
              );
            })}
          </svg>

          {/* Canvas legend */}
          <div className="absolute bottom-2.5 right-3 bg-white/95 backdrop-blur-sm border border-slate-150 px-2.5 py-1.5 rounded-lg shadow-sm text-[9px] flex items-center gap-3.5 text-gray-500 font-medium">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 bg-[#ef4444] rounded-full"></span> 露露
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 bg-[#065f46] rounded-full"></span> Manner
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 bg-[#b45309] rounded-full"></span> 巴塔
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 bg-[#84cc16] rounded-full"></span> 奈雪
            </span>
            <span className="h-3 w-px bg-gray-200"></span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 border border-dashed border-gray-400 rounded-full"></span> 策略
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 bg-gray-500 rounded-full"></span> 活动/推文
            </span>
          </div>
        </div>

        {/* Connection analysis details panel (Right side) */}
        <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl flex flex-col justify-between" id="connection-details-panel">
          {activeRelation ? (
            <div className="flex flex-col h-full justify-between gap-4">
              <div>
                <div className="flex items-center justify-between mb-3.5">
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${relationshipTypes[activeRelation.relationType].bg} ${relationshipTypes[activeRelation.relationType].color} ${relationshipTypes[activeRelation.relationType].border}`}>
                    {relationshipTypes[activeRelation.relationType].label}
                  </span>
                  
                  {activeRelation.isAiGenerated && (
                    <span className="text-[9px] font-medium text-indigo-600 bg-indigo-50 border border-indigo-100 flex items-center gap-0.5 px-2 py-0.5 rounded-full">
                      <Sparkles className="w-2.5 h-2.5" /> AI研判
                    </span>
                  )}
                </div>

                {/* Sources info */}
                <div className="space-y-3.5" id="relation-connectors-display">
                  <div className="bg-white border border-gray-100 p-3 rounded-lg relative overflow-hidden shadow-sm">
                    <span className="absolute top-0 left-0 bottom-0 w-1 bg-indigo-500"></span>
                    <div className="text-[10px] text-gray-400 font-bold tracking-wider">{activeRelation.sourceBrandName}</div>
                    <div className="text-xs font-semibold text-gray-800 mt-0.5 line-clamp-1">{activeRelation.sourceTitle}</div>
                    <button
                      onClick={() => onSelectNode(activeRelation.sourceType as any, activeRelation.sourceId)}
                      className="text-[9px] text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-0.5 mt-1.5 cursor-pointer"
                    >
                      <Eye className="w-3 h-3" /> 点击跳转查看
                    </button>
                  </div>

                  <div className="flex justify-center my-0.5 text-gray-300">
                    <Zap className="w-4 h-4 fill-amber-300 text-amber-500" />
                  </div>

                  <div className="bg-white border border-gray-100 p-3 rounded-lg relative overflow-hidden shadow-sm">
                    <span className="absolute top-0 left-0 bottom-0 w-1 bg-indigo-500"></span>
                    <div className="text-[10px] text-gray-400 font-bold tracking-wider">{activeRelation.targetBrandName}</div>
                    <div className="text-xs font-semibold text-gray-800 mt-0.5 line-clamp-1">{activeRelation.targetTitle}</div>
                    <button
                      onClick={() => onSelectNode(activeRelation.targetType as any, activeRelation.targetId)}
                      className="text-[9px] text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-0.5 mt-1.5 cursor-pointer"
                    >
                      <Eye className="w-3 h-3" /> 点击跳转查看
                    </button>
                  </div>
                </div>

                <div className="border-t border-gray-200/60 my-4"></div>

                {/* Core descriptions analysis */}
                <h4 className="text-xs font-bold text-gray-700 tracking-wide">💡 关联深度解读：</h4>
                <div className="bg-slate-100/60 p-3.5 rounded-lg border border-slate-200/50 mt-2">
                  <p className="text-xs text-slate-700 leading-relaxed font-normal whitespace-pre-wrap">
                    {activeRelation.description}
                  </p>
                </div>
              </div>

              {/* Confidence rating and metrics */}
              {activeRelation.confidence && (
                <div className="bg-indigo-50/50 border border-indigo-100/50 rounded-lg px-3.5 py-2.5 flex items-center justify-between text-[11px] font-medium text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-indigo-500" />
                    关联融通契合度：
                  </span>
                  <span className="font-bold text-indigo-600 text-xs">{(activeRelation.confidence * 100).toFixed(0)}%</span>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center py-16 text-gray-400 my-auto">
              <HelpCircle className="w-10 h-10 mb-2 stroke-gray-300 stroke-[1.5]" />
              <p className="text-xs font-semibold text-gray-500">还未选择任何连线</p>
              <p className="text-[11px] text-gray-400 mt-1 max-w-[200px]">
                点击左侧星图中【连接黑灰/紫色的虚实彩线】，即可立即在此处提取 AI 对跨界玩法的深度解剖报告。
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Write manual relationship builder modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/45 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-xl overflow-hidden animate-in fade-in duration-200">
            <div className="bg-slate-50 border-b border-gray-100 p-5 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
                <Link2 className="w-4 h-4 text-indigo-600" />
                手动创建两条知识的语义关联
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600 font-bold text-lg"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateCustomRelation} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Source Selection */}
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">出发节点 (本源信息)*</label>
                  <select
                    required
                    value={sourceNodeId}
                    onChange={(e) => setSourceNodeId(e.target.value)}
                    className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-2 outline-none focus:border-indigo-500"
                  >
                    <option value="">-- 请选择 --</option>
                    {allNodes.map(node => (
                      <option key={node.id} value={node.id}>[{node.brandName}] {node.title.slice(0, 30)}...</option>
                    ))}
                  </select>
                </div>

                {/* Target Selection */}
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">关联指向节点 (契合信息)*</label>
                  <select
                    required
                    value={targetNodeId}
                    onChange={(e) => setTargetNodeId(e.target.value)}
                    className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-2 outline-none focus:border-indigo-500"
                  >
                    <option value="">-- 请选择 --</option>
                    {allNodes.map(node => (
                      <option key={node.id} value={node.id}>[{node.brandName}] {node.title.slice(0, 30)}...</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Connection Type */}
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1.5">关联属性类型*</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(Object.keys(relationshipTypes) as RelationType[]).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setCustomRelationType(type)}
                      className={`text-[10px] font-medium py-1.5 px-2.5 rounded-lg border text-left transition-all ${
                        customRelationType === type
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold'
                          : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {relationshipTypes[type].label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1.5">您的跨界关联创意分析 / 提炼理由*</label>
                <textarea
                  required
                  rows={4}
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  placeholder="例：这两家品牌的动作都具有强社交打卡和道德尊严红利。我们可以拿奈雪的做法去改良本品牌针对上海高档社区的包装，在瓶盖上融合..."
                  className="w-full text-xs border border-gray-200 rounded-lg p-3 outline-none focus:border-indigo-500"
                ></textarea>
                <p className="text-[10px] text-gray-400 mt-1">
                  您的精辟分析不仅会被保存在关联列表中。在未来启动 [AI创意梦工坊] 策划时，这些手动添加的高阶关联也将作为您最具分量的私域灵感语境。
                </p>
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="text-xs border border-gray-200 text-gray-600 font-medium px-4 py-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="text-xs bg-indigo-600 text-white font-medium px-4 py-2 rounded-lg hover:bg-indigo-700 shadow cursor-pointer"
                >
                  写入星图
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
