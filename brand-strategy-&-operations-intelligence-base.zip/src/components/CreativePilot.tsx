import React, { useState } from 'react';
import { Sparkles, Trash2, Send, Copy, Check, Info, FileText, ArrowRight } from 'lucide-react';
import Markdown from 'react-markdown';

interface CreativePilotProps {
  selectedItems: Array<{
    id: string;
    type: 'strategy' | 'action' | 'operation';
    title: string;
    brandName: string;
    contentSummary: string;
  }>;
  onRemoveItem: (id: string) => void;
  onClearAll: () => void;
}

export default function CreativePilot({ selectedItems, onRemoveItem, onClearAll }: CreativePilotProps) {
  const [customInstruction, setCustomInstruction] = useState('');
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [activePreset, setActivePreset] = useState<number | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);

  const promptPresets = [
    {
      title: "🤝 双品牌跨界物理联名及首发方案",
      prompt: "设计一个极具故事感、能引爆小红书流量的全国级双品牌联名合作（包含联名杯具/面料、核心画外画、以及首发快闪仪式互动细节）。"
    },
    {
      title: "🚗 创意跨界迁移至新能源汽车行业",
      prompt: "这些玩法如何迁移至“新能源汽车”或“高档美妆”行业？请详细分析并设计一套适合全新车型的、突出环保或自我价值的主题社群巡游活动方案。"
    },
    {
      title: "🎨 小红书爆款种草图文写作方案",
      prompt: "模仿这些案例的文案风格、情绪切入点和图片排版美学，帮我们撰写3篇针对不同圈层（攀岩发烧友、办公室久坐白领、古风爱好者）的小红书种草文案草稿，包含带表情与标签的话术。"
    }
  ];

  const handleApplyPreset = (index: number, promptText: string) => {
    setActivePreset(index);
    setCustomInstruction(promptText);
  };

  const handleGenerateReport = async () => {
    if (selectedItems.length === 0) {
      alert("请至少在左侧列表勾选并添加 1 个关联灵感素材才能激发 AI 创意分析！");
      return;
    }

    setIsLoading(true);
    setApiError(null);
    setAiReport(null);

    try {
      const response = await fetch("/api/brand/creative", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          selectedItems: selectedItems.map(item => ({
            id: item.id,
            type: item.type,
            title: item.title,
            brandName: item.brandName,
            summary: item.contentSummary
          })),
          customInstruction: customInstruction || "请根据这些勾选的案例，帮我在这些品牌中碰撞出一个前所未有的、能引爆小红书传播的跨界活动或内容方案。"
        })
      });

      if (!response.ok) {
        throw new Error(`服务器响应异常: ${response.status}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setAiReport(data.report);
    } catch (error: any) {
      console.error("Brainstorming error:", error);
      setApiError(error.message || "未知服务异常，请稍后重试");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyReport = () => {
    if (!aiReport) return;
    navigator.clipboard.writeText(aiReport);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden p-6" id="creative-pilot-container">
      {/* Box header */}
      <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <span className="p-1.5 bg-amber-50 text-amber-500 rounded-lg">
            <Sparkles className="w-5 h-5 fill-amber-400" />
          </span>
          <div>
            <h2 className="text-sm font-semibold text-gray-800">AI 创意梦工坊</h2>
            <p className="text-[10px] text-gray-400">将选中的零散内容通过大模型进行创意脑洞众筹与跨界策划</p>
          </div>
        </div>

        {selectedItems.length > 0 && (
          <button
            onClick={onClearAll}
            className="text-[10px] text-red-500 font-medium hover:text-red-700 flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-3 h-3" />
            清空已选灵感
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left materials console: list of selected inputs */}
        <div className="md:col-span-5 flex flex-col justify-between border-b md:border-b-0 md:border-r border-gray-100 pb-5 md:pb-0 md:pr-6">
          <div>
            <h3 className="text-xs font-bold text-gray-700 flex items-center gap-1.5 mb-3">
              <FileText className="w-4 h-4 text-indigo-500" />
              已勾选的灵感种子 ({selectedItems.length})
            </h3>

            {selectedItems.length > 0 ? (
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1" id="creative-seeds-list">
                {selectedItems.map((item) => (
                  <div
                    key={item.id}
                    className="group flex items-start justify-between bg-slate-50 border border-slate-100 p-2.5 rounded-lg text-xs leading-relaxed transition-all hover:bg-slate-100/70"
                  >
                    <div className="pr-2">
                      <span className="inline-block text-[8px] font-bold px-1.5 py-0.5 rounded-md bg-white border border-gray-100 text-gray-500 mr-1">
                        {item.type === 'strategy' ? '策略' : item.type === 'action' ? '活动' : '推文'}
                      </span>
                      <span className="font-bold text-slate-700">{item.brandName}</span>
                      <p className="text-slate-600 mt-1 line-clamp-2">{item.title}</p>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-gray-400 hover:text-red-500 p-1 rounded transition-colors self-center opacity-0 group-hover:opacity-100 cursor-pointer"
                      title="移除此灵感"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-50 border border-dashed border-gray-200/80 rounded-xl py-12 px-6 text-center text-gray-400" id="empty-seeds-panel">
                <Info className="w-8 h-8 mx-auto text-gray-300 stroke-[1.5] mb-2" />
                <p className="text-[11px] font-semibold text-gray-500">还未勾选任何灵感种子</p>
                <p className="text-[10px] text-gray-400 mt-1 leading-normal max-w-[220px] mx-auto">
                  请多看下各品牌的<b>[年度策略]</b>、<b>[营销活动]</b>或<b>[新媒体推文]</b>，点击卡片右上角的复选框将其装入素材库。
                </p>
              </div>
            )}
          </div>

          {/* Quick presets list for drafting inspiration */}
          <div className="mt-5 pt-4 border-t border-gray-100/80">
            <h4 className="text-[10px] font-bold text-gray-500 tracking-wider mb-2">💡 专家推荐脑洞方向：</h4>
            <div className="space-y-1.5">
              {promptPresets.map((preset, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleApplyPreset(index, preset.prompt)}
                  className={`w-full text-left text-[11px] px-3 py-2 rounded-lg border flex items-center justify-between transition-all cursor-pointer ${
                    activePreset === index
                      ? 'border-indigo-600 bg-indigo-50/60 font-semibold text-indigo-700 shadow-sm'
                      : 'border-slate-100 bg-white text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span className="line-clamp-1 pr-1">{preset.title}</span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right input briefer: prompts, trigger outputs */}
        <div className="md:col-span-7 flex flex-col justify-between" id="creative-workbench">
          <div className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">您的创意众筹简报 / 定制问题描绘</label>
              <div className="relative">
                <textarea
                  rows={2}
                  value={customInstruction}
                  onChange={(e) => {
                    setCustomInstruction(e.target.value);
                    setActivePreset(null);
                  }}
                  className="w-full text-xs border border-gray-200 rounded-xl pl-3.5 pr-12 py-3 bg-slate-50 outline-none focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none font-normal leading-relaxed"
                  placeholder="写下：这些做法结合起来，可以帮一家高端新能源SUV汽车写一份针对小红书新车交付的车主修补旅途故事集文案吗..."
                ></textarea>
                <button
                  onClick={handleGenerateReport}
                  disabled={isLoading || selectedItems.length === 0}
                  className={`absolute right-2.5 bottom-2.5 p-2 rounded-xl text-white transition-all shadow cursor-pointer ${
                    selectedItems.length === 0 
                      ? 'bg-gray-300 cursor-not-allowed shadow-none' 
                      : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95'
                  }`}
                  title="生成灵感方案"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Error messaging bar */}
            {apiError && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-lg text-xs text-red-600 flex items-start gap-2">
                <Info className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">分析中断：{apiError}</p>
                  <p className="text-[10px] text-red-500 mt-0.5">请确保您已在 Settings ⚙️ ➜ Secrets 中填充有效的 API Key。系统目前将继续提供高级启发，稍后重试。</p>
                </div>
              </div>
            )}

            {/* Markdown Report Render box */}
            <div className="border border-slate-150 rounded-xl bg-slate-50 overflow-hidden relative shadow-inner">
              {/* Header label for loading state or copy */}
              <div className="bg-white border-b border-gray-150/40 px-4 py-2.5 flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold flex items-center gap-1.5 text-indigo-600">
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  灵感魔方编译输出板
                </span>

                {aiReport && (
                  <button
                    onClick={handleCopyReport}
                    className="flex items-center gap-1 text-[11px] text-gray-500 hover:text-indigo-600 font-medium transition-colors cursor-pointer"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-green-500" />
                        已复制
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        一键复制创意案
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Content Panel Scroll area */}
              <div className="p-4 overflow-y-auto max-h-[380px] min-h-[220px]" id="creative-report-body">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400 gap-3">
                    <div className="w-8 h-8 rounded-full border-4 border-indigo-200 border-t-indigo-600 animate-spin"></div>
                    <div>
                      <p className="text-xs font-semibold text-slate-600">正在链接 4A 智脑进行跨界推导...</p>
                      <p className="text-[10px] text-slate-400 mt-1 max-w-[220px]">
                        结合 {selectedItems.length} 个跨界经典品牌心智与您的定制 Brief，可能需要 10-15 秒，请稍候。
                      </p>
                    </div>
                  </div>
                ) : aiReport ? (
                  <div className="prose prose-slate max-w-none text-xs text-slate-700 leading-relaxed font-normal whitespace-pre-wrap prose-sm prose-headings:font-bold prose-headings:text-slate-800 prose-p:text-slate-600">
                    <Markdown>{aiReport}</Markdown>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center text-center py-12 text-slate-400">
                    <div className="p-3 bg-amber-50/60 rounded-full border border-amber-100 text-amber-500 mb-2">
                      <Sparkles className="w-5 h-5 fill-amber-300" />
                    </div>
                    <p className="text-xs font-semibold text-slate-500">等待创意激发</p>
                    <p className="text-[10px] text-slate-400 mt-1 max-w-[260px] leading-normal">
                      在左侧面板检查或点选要融合的研究对象，选择或填写您要做策划的行业，点击发送按钮！
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
