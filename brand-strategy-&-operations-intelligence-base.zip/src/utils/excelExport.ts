import * as XLSX from 'xlsx';
import { KnowledgeBaseData } from '../types';

export function downloadKnowledgeBaseAsExcel(data: KnowledgeBaseData) {
  const wb = XLSX.utils.book_new();

  // Create brand ID to name mapping for quick lookup
  const brandMap = new Map<string, string>();
  data.brands.forEach(b => {
    brandMap.set(b.id, b.name);
  });

  // Sheet 1: 品牌大览 (Brands Overview)
  const brandsSheetData = data.brands.map(b => {
    let customSectionsStr = '';
    if (b.customSections && b.customSections.length > 0) {
      customSectionsStr = b.customSections
        .map(sec => `【${sec.title}】: ${sec.content}`)
        .join('\n');
    }

    return {
      '品牌ID': b.id,
      '品牌名称': b.name,
      '所属行业分类': b.industry,
      '品牌核心定位与介绍': b.description,
      '添加的自定义板块': customSectionsStr || '暂无自定义补充信息'
    };
  });
  const wsBrands = XLSX.utils.json_to_sheet(brandsSheetData);
  XLSX.utils.book_append_sheet(wb, wsBrands, '1. 智能品牌概览');

  // Sheet 2: 年度商业大观 (Annual Strategies)
  const strategiesSheetData = data.strategies.map(s => {
    const brandName = brandMap.get(s.brandId) || `未知品牌ID(${s.brandId})`;
    return {
      '所属品牌': brandName,
      '年度年份': `${s.year}年`,
      '年度传播口号精神': s.tagline,
      '核心战役聚焦点': s.coreFocus,
      '年度受众画像群体': s.targetAudience,
      '核心标签词': (s.keywords || []).join(', '),
      '营收及商业盘点大局': s.revenueInfo || '暂无具体数据',
      '实体/线上门店变动情景': s.storeCountInfo || '暂无具体指标',
      '年度主推重磅商品': s.keyProductsInfo || '暂无商品信息'
    };
  });
  const wsStrategies = XLSX.utils.json_to_sheet(strategiesSheetData);
  XLSX.utils.book_append_sheet(wb, wsStrategies, '2. 品牌年度策略');

  // Sheet 3: 特色营销活动与战役 (Marketing Actions)
  const actionsSheetData = data.actions.map(a => {
    const brandName = brandMap.get(a.brandId) || `未知品牌-ID(${a.brandId})`;
    return {
      '所属品牌': brandName,
      '活动具体日期': a.date,
      '关联的季度': a.quarter || '跨季度/全年度',
      '活动标题名称': a.title,
      '营销动作分类': a.type,
      '宣发投放渠道': (a.channels || []).join(' | '),
      '详细玩法规则与创意链路': a.description,
      '营销结果成效及定性研判': a.results || '暂未录入结果数据',
      '本季度策略特征大纲': a.quarterlySummary || '暂无具体汇总',
      '本季重磅新品及商品细节': a.newProducts || '暂无新品细节'
    };
  });
  const wsActions = XLSX.utils.json_to_sheet(actionsSheetData);
  XLSX.utils.book_append_sheet(wb, wsActions, '3. 品牌营销活动');

  // Sheet 4: 社交媒体运营及季度盘点 (New Media Operations)
  const operationsSheetData = data.operations.map(o => {
    const brandName = brandMap.get(o.brandId) || `未知品牌ID(${o.brandId})`;
    
    // Map platform code to Chinese
    let platformName = o.platform;
    if (o.platform === 'Red') platformName = '小红书' as any;
    else if (o.platform === 'Weixin') platformName = '微信官号' as any;
    else if (o.platform === 'Weibo') platformName = '微博' as any;
    else if (o.platform === 'Douyin') platformName = '抖音' as any;
    else if (o.platform === 'Bilibili') platformName = '哔哩哔哩' as any;
    
    let isSummaryStr = o.isQuarterlySummary ? '是 (大盘汇总卡片)' : '否 (具体推文/帖子)';
    
    // Flatten three platform details if quarterly summary
    let platformIntelStr = '';
    if (o.isQuarterlySummary && o.platformsIntel && o.platformsIntel.length > 0) {
      platformIntelStr = o.platformsIntel.map(intel => {
        const plat = intel.platformName === 'Douyin' ? '抖音' : intel.platformName === 'Red' ? '小红书' : '微信官号';
        return `【${plat}】发帖量: ${intel.postCount} | 主旨: ${intel.mainTheme} | 风格: ${intel.overallStyle} | 重点: ${intel.keyMessages}`;
      }).join('\n');
    }

    return {
      '所属品牌': brandName,
      '发帖日期': o.postDate,
      '对应季度': o.quarter || '无/日常运营',
      '具体渠道/平台': platformName,
      '运营账号名': o.accountName,
      '推文主题或汇总大盘': o.postTitle,
      '正文脚本内容 / 季度社交心理总结': o.postContent,
      '海报视觉调性与设计主调': o.visualStyle || '未特别规定',
      '历史互动实录数据指标': o.interactionCount,
      '是否为季度智能汇总': isSummaryStr,
      '自营三个核心社媒季度盘点(仅限汇总卡)': platformIntelStr || '非季度汇总卡或无平台详情'
    };
  });
  const wsOperations = XLSX.utils.json_to_sheet(operationsSheetData);
  XLSX.utils.book_append_sheet(wb, wsOperations, '4. 社媒运营大盘');

  // Sheet 5: AI 联想关联与星宿图谱纽带 (Relationships)
  const relationshipsSheetData = data.relationships.map(r => {
    // Translate source-target type
    const typeCN = (t: string) => {
      if (t === 'brand') return '品牌主体';
      if (t === 'strategy') return '年度商业口号';
      if (t === 'action') return '营销活动战役';
      if (t === 'operation') return '自营社媒推文';
      return t;
    };

    // Translate relation types
    const relationCN = (rel: string) => {
      switch (rel) {
        case 'similar_tactic': return '同类玩法相似';
        case 'part_of_strategy': return '落地实践关联';
        case 'inspired_by': return '模式创意启发';
        case 'co_branding': return '跨界联名共创';
        case 'cross_industry_reference': return '跨行业对照借鉴';
        case 'custom': return '自定义关联纽带';
        default: return rel;
      }
    };

    return {
      '源节点所属品牌': r.sourceBrandName,
      '源节点类别': typeCN(r.sourceType),
      '源端核心标题': r.sourceTitle,
      '关联维度模式': relationCN(r.relationType),
      '目标所属品牌': r.targetBrandName,
      '目标节点类别': typeCN(r.targetType),
      '目标端核心标题': r.targetTitle,
      '深度交叉联想与共同点阐述': r.description,
      'AI联想置信匹配度': r.confidence !== undefined ? `${(r.confidence * 100).toFixed(0)}%` : '100%',
      '关联建立渠道': r.isAiGenerated ? 'AI 智能跨行业大算推荐' : '人工手动建立'
    };
  });
  const wsRelationships = XLSX.utils.json_to_sheet(relationshipsSheetData);
  XLSX.utils.book_append_sheet(wb, wsRelationships, '5. AI大跨界星宿关联图');

  // Set nice column widths for sheets
  const sheets = [wsBrands, wsStrategies, wsActions, wsOperations, wsRelationships];
  sheets.forEach(sh => {
    const range = XLSX.utils.decode_range(sh['!ref'] || 'A1:A1');
    const cols = [];
    for (let c = range.s.c; c <= range.e.c; ++c) {
      cols.push({ wch: 22 }); // Set a spacious default column width
    }
    sh['!cols'] = cols;
  });

  // Save the excel file
  const dateStr = new Date().toISOString().split('T')[0];
  XLSX.writeFile(wb, `品牌策略与自营媒体脑脑洞智库_${dateStr}.xlsx`);
}
