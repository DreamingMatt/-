export interface Brand {
  id: string;
  name: string;
  logoColor: string; // Tailwind bg color class for visual branding
  industry: string;
  description: string;
  customSections?: Array<{ id: string; title: string; content: string }>;
}

export interface AnnualStrategy {
  id: string;
  brandId: string;
  year: number;
  tagline: string;
  keywords: string[];
  targetAudience: string;
  coreFocus: string;
  createdAt?: string;
  // Newly requested fields for annual business report summaries (年度商业报告总结)
  revenueInfo?: string;      // 营收情况
  storeCountInfo?: string;   // 开店闭店情况
  keyProductsInfo?: string;  // 重点新品
}

export interface MarketingAction {
  id: string;
  brandId: string;
  title: string;
  date: string;
  type: string; // e.g., "联名合作", "线下快闪", "公益环保", "线上裂变"
  description: string;
  channels: string[]; // e.g., ["微信", "小红书", "抖音"]
  results: string; // operation outcomes or core mechanics
  createdAt?: string;
  // Newly requested fields for quarterly marketing activities
  quarter?: 'Q1' | 'Q2' | 'Q3' | 'Q4'; // 对应季度
  quarterlySummary?: string;            // 季度总结
  newProducts?: string;                 // 推出新产品和产品信息
}

export interface NewMediaPlatformIntel {
  platformName: 'Douyin' | 'Red' | 'Weixin';
  postCount: number | string;   // 发文数量
  mainTheme: string;            // 内容主旨
  overallStyle: string;         // 整体风格
  keyMessages: string;          // 重点信息
}

export interface NewMediaOperation {
  id: string;
  brandId: string;
  platform: 'Red' | 'Weixin' | 'Weibo' | 'Douyin' | 'Bilibili' | 'Other'; // 小红书, 微信, 微博, 抖音, B站
  accountName: string;
  postTitle: string;
  postContent: string;
  visualStyle: string;
  postUrl?: string;
  postDate: string;
  interactionCount: string; // e.g., "点赞1.2k, 评论300"
  createdAt?: string;
  // Newly requested fields for quarterly summaries
  quarter?: 'Q1' | 'Q2' | 'Q3' | 'Q4'; // 对应季度
  isQuarterlySummary?: boolean;         // 是否是季度汇总
  platformsIntel?: NewMediaPlatformIntel[]; // 官方社媒三个平台的信息
}

export type RelationType = 
  | 'similar_tactic'           // 同类玩法: content/interaction strategy is similar
  | 'part_of_strategy'         // 落地实践: a post/campaign belongs to a specific strategy
  | 'inspired_by'              // 创意启发: Brand A's campaign is inspired by Brand B
  | 'co_branding'              // 联名跨界: joint campaign or product release
  | 'cross_industry_reference' // 跨界借鉴: referencing high-level logic from another industry
  | 'custom';                  // 自定义关联

export interface Relationship {
  id: string;
  sourceId: string;
  sourceType: 'brand' | 'strategy' | 'action' | 'operation';
  sourceTitle: string; // Denormalized for display ease
  sourceBrandName: string;
  
  targetId: string;
  targetType: 'brand' | 'strategy' | 'action' | 'operation';
  targetTitle: string; // Denormalized for display ease
  targetBrandName: string;
  
  relationType: RelationType;
  description: string; // Summary of why they correspond
  confidence?: number; // 0 to 1 for AI-generated matches
  isAiGenerated: boolean;
}

// Full application payload for exchange and UI state
export interface KnowledgeBaseData {
  brands: Brand[];
  strategies: AnnualStrategy[];
  actions: MarketingAction[];
  operations: NewMediaOperation[];
  relationships: Relationship[];
}
